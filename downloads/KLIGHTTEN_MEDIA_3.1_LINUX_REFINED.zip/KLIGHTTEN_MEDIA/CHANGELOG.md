# Changelog

## 3.1.0

- Restored Media Control Panel.
- Restored visible Now Playing navigation.
- Normalized Linux minimize behavior.
- Made Floating Video manual-only and added a persistent toggle.
- Expanded canonical themes across the whole workspace.
- Cleaned cramped controls and ani-cli maintenance layout.
- Introduced the white headphone / KLIGHTTEN mark / reading-waveform brand emblem.

## 3.0.0 — Linux Edition

- Reorganized navigation into Home, Music, YouTube, Local, Anime, Converter, Queue and Settings.
- Added ArchiveTune-inspired Music workspace for songs, artists, albums, playlists, favorites and history.
- Added persistent full YouTube Qt WebEngine browser with back/forward/reload/home/address navigation.
- Separated fullscreen keys: F = MPV, Y = YouTube, F11 = application.
- Added Ctrl+Esc application exit. Esc alone is no longer a fullscreen command.
- Added minimal Reload/Copy/Paste right-click menu.
- Replaced old themes with the five canonical KLIGHTTEN palettes.
- Added Download / Upgrade Dependencies terminal workflow.
- `ani-cli -U` is displayed only while updating ani-cli.
- Added new KLIGHTTEN MEDIA brand icon and Linux desktop icon sizes.
- Declared Linux-only release behavior in run/setup scripts.
- Rewrote README for public GitHub distribution.

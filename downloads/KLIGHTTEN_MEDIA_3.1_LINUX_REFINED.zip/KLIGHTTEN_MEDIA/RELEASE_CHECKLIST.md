# Release Checklist

- [ ] `./diagnose.sh` passes
- [ ] App starts only once
- [ ] Canonical branding appears in launcher/panel/titlebar
- [ ] All primary tabs open
- [ ] Media Control Panel remains visible
- [ ] Five canonical themes affect the whole workspace
- [ ] Minimize does not auto-float
- [ ] Float Video is manual
- [ ] `F`, `Y`, `F11`, `Ctrl + Esc` behave correctly
- [ ] ani-cli starts/stops
- [ ] Website download SHA matches release

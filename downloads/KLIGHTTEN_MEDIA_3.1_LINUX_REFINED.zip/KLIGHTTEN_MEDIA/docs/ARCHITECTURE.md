# Architecture

```text
HTML/CSS/JS UI
      │
      ↓
  QWebChannel
      │
      ↓
 Python AppAPI
      │
 ┌────┼────────┐
 ↓    ↓        ↓
MPV WebEngine GStreamer
```

`qt_shell.py` owns Linux windowing, WebEngine, single-instance behavior, application icons, native-video surfaces and global shortcuts.

`main.py` owns media state, queues, libraries, ani-cli integration, conversion, settings and OAuth helpers.

Floating Video is manual. Minimize performs a normal Linux minimize.

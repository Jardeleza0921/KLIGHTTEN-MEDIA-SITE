# Keyboard & Controls

| Shortcut | Action |
|---|---|
| `F` | MPV/native-video fullscreen |
| `Y` | YouTube fullscreen |
| `F11` | Whole-app fullscreen |
| `Ctrl + Esc` | Exit |
| `M` | Mute |
| `S` | Shuffle |
| `Space` | Play / pause |
| `←` / `→` | Seek |

Right click:

```text
Reload
Copy
Paste
```

Minimize does not automatically enable Floating Video.

# Troubleshooting

Start with:

```bash
./diagnose.sh
```

If KLIGHTTEN does not start, run `./run.sh` in a terminal and capture the traceback.

YouTube uses Qt WebEngine / Chromium. Local and ani-cli video use MPV.

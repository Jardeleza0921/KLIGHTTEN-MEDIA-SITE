#!/usr/bin/env python3
import ctypes, os, signal, sys
PR_SET_PDEATHSIG=1

def main():
    if len(sys.argv)<2: return 2
    parent_pid=os.getppid()
    try: os.setsid()
    except Exception: pass
    if sys.platform.startswith('linux'):
        try:
            libc=ctypes.CDLL(None,use_errno=True)
            libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
            libc.prctl.restype=ctypes.c_int
            libc.prctl(PR_SET_PDEATHSIG,signal.SIGTERM,0,0,0)
            if os.getppid()!=parent_pid: os.kill(os.getpid(),signal.SIGTERM)
        except Exception: pass
    program=sys.argv[1]
    os.execv(program,[program]+sys.argv[2:])
if __name__=='__main__': raise SystemExit(main())

<p align="center">
  <img src="assets/klightten-media-brand.png" width="360" alt="KLIGHTTEN MEDIA">
</p>

<h1 align="center">KLIGHTTEN MEDIA</h1>

<p align="center">
  <strong>Linux-first entertainment workspace by Klightten Industries.</strong><br>
  Music • YouTube • Local Media • ani-cli • MPV • FFmpeg
</p>

<p align="center"><code>v3.1.0</code> · <code>Linux only</code> · <code>Python + Qt WebEngine</code> · <code>MPV</code> · <code>FFmpeg</code></p>

---

## Overview

KLIGHTTEN MEDIA is a Linux desktop media workspace that brings the most-used entertainment workflows into one application.

```text
KLIGHTTEN MEDIA
├── Home
├── Music
├── YouTube
├── Local
│   ├── Music
│   └── Videos
├── Anime
├── Now Playing
├── Converter
├── Queue
└── Settings
```

## Highlights

- ArchiveTune-inspired Music workflow.
- Persistent YouTube browser through Qt WebEngine / Chromium.
- Local music/video through MPV.
- ani-cli terminal workflow with native MPV playback.
- Persistent Media Control Panel and dedicated Now Playing workspace.
- Manual Floating Video toggle; minimize does not automatically float video.
- Local FFmpeg Converter Studio.
- Single-instance Linux desktop behavior.
- Five canonical KLIGHTTEN themes across the full workspace.
- Canonical KLIGHTTEN MEDIA Neon-Arcade branding.

## Screenshots

<table>
<tr>
<td><img src="docs/screenshots/anime-workspace.png" alt="Anime workspace"></td>
<td><img src="docs/screenshots/settings-themes.png" alt="Settings and themes"></td>
</tr>
</table>

## Playback architecture

```text
Music / Local Audio ───────────────→ MPV
Local Video ───────────────────────→ MPV native video surface
ani-cli resolved video ────────────→ MPV native video surface
YouTube website ───────────────────→ Qt WebEngine / Chromium
Emergency local-audio fallback ───→ GStreamer
Local conversion ─────────────────→ FFmpeg
```

## Keyboard navigation

| Key | Function |
|---|---|
| `F` | MPV/native-video fullscreen |
| `Y` | YouTube fullscreen |
| `F11` | Whole-app fullscreen |
| `Ctrl + Esc` | Exit KLIGHTTEN MEDIA |
| `M` | Mute / unmute |
| `S` | Shuffle toggle |
| `Space` | Play / pause outside text inputs |
| `←` / `→` | Seek backward / forward |

`Esc` alone is not a KLIGHTTEN fullscreen shortcut.

## Canonical themes

| Theme | Identity |
|---|---|
| Dark-Mint | Bunny |
| Neon-Arcade | Cat |
| Black-White | Wolf |
| Crimson-Red | Fox |
| Cream Coffee | Dog |

Canonical Neon-Arcade mark:

```text
//  =  ^  w  ^  =  )
```

## Install

```bash
unzip KLIGHTTEN_MEDIA_3.1_LINUX_REFINED.zip
cd KLIGHTTEN_MEDIA
chmod +x setup.sh run.sh diagnose.sh upgrade-dependencies.sh
./setup.sh
./run.sh
```

After setup: `./run.sh`

Diagnostics: `./diagnose.sh`

## Repository map

```text
.
├── main.py
├── qt_shell.py
├── mpv_guard.py
├── ui/index.html
├── assets/
├── docs/
├── setup.sh
├── run.sh
├── diagnose.sh
├── upgrade-dependencies.sh
├── CHANGELOG.md
├── BRANDING.md
├── THIRD_PARTY.md
└── README.md
```

## Documentation

- [Architecture](docs/ARCHITECTURE.md)
- [Keyboard & Controls](docs/CONTROLS.md)
- [Branding](BRANDING.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Release Checklist](RELEASE_CHECKLIST.md)
- [Third-party projects](THIRD_PARTY.md)

## ArchiveTune reference

ArchiveTune is the primary music-workflow reference for KLIGHTTEN MEDIA. KLIGHTTEN MEDIA does not use ArchiveTune's official branding and is not presented as an ArchiveTune distribution.

ArchiveTune: https://github.com/rukamori/ArchiveTune

## Credits

Qt / Qt WebEngine • MPV • FFmpeg • GStreamer • ani-cli • ArchiveTune (workflow reference)

KLIGHTTEN MEDIA is an independent Klightten Industries project.

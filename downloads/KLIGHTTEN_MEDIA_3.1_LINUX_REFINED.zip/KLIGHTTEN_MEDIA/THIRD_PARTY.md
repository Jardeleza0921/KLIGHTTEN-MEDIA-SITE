# Third-party projects

KLIGHTTEN MEDIA integrates with or is inspired by several open-source projects.

- **ArchiveTune** — music workflow/feature reference. KLIGHTTEN MEDIA does not use ArchiveTune branding.
- **MPV** — native audio/video playback.
- **FFmpeg** — media conversion and codec utilities.
- **Qt / Qt WebEngine** — desktop UI shell and Chromium rendering.
- **ani-cli** — optional anime terminal workflow.

Refer to each upstream project for its own license and terms.

#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

if [[ "$(uname -s)" != "Linux" ]]; then
  echo "KLIGHTTEN MEDIA is a Linux desktop application."
  echo "This release does not support Windows or macOS."
  exit 1
fi

export QT_QUICK_BACKEND=software

# Recover only orphaned KLIGHTTEN MPV players from an older/crashed build.
# Never touch MPV while a KLIGHTTEN Qt instance is still alive.
if ! pgrep -u "$(id -u)" -f "$APP_DIR/qt_shell.py" >/dev/null 2>&1; then
  pkill -TERM -u "$(id -u)" -f 'mpv .*--input-ipc-server=.*/klightten-video-[0-9].*\.sock' 2>/dev/null || true
  sleep 0.15
  pkill -KILL -u "$(id -u)" -f 'mpv .*--input-ipc-server=.*/klightten-video-[0-9].*\.sock' 2>/dev/null || true
  rm -f /tmp/klightten-video-*.sock /tmp/klightten-video-key-*.txt 2>/dev/null || true
fi

# Refresh the Linux launcher/panel metadata on every app update.
APP_ID="io.github.jardeleza0921.klighttenmedia"
DESKTOP_DIR="$HOME/.local/share/applications"
ICON_ROOT="$HOME/.local/share/icons/hicolor"
mkdir -p "$DESKTOP_DIR" "$ICON_ROOT/scalable/apps" "$ICON_ROOT/128x128/apps" "$ICON_ROOT/256x256/apps" "$ICON_ROOT/512x512/apps"
cp -f "$APP_DIR/assets/klightten-media.svg" "$ICON_ROOT/scalable/apps/klightten-media.svg" 2>/dev/null || true
[[ -f "$APP_DIR/assets/klightten-media-128.png" ]] && cp -f "$APP_DIR/assets/klightten-media-128.png" "$ICON_ROOT/128x128/apps/klightten-media.png" 2>/dev/null || true
[[ -f "$APP_DIR/assets/klightten-media-256.png" ]] && cp -f "$APP_DIR/assets/klightten-media-256.png" "$ICON_ROOT/256x256/apps/klightten-media.png" 2>/dev/null || true
[[ -f "$APP_DIR/assets/klightten-media-512.png" ]] && cp -f "$APP_DIR/assets/klightten-media-512.png" "$ICON_ROOT/512x512/apps/klightten-media.png" 2>/dev/null || true
rm -f "$DESKTOP_DIR/klightten-music.desktop" "$DESKTOP_DIR/io.github.jardeleza0921.klighttenmusic.desktop" 2>/dev/null || true
cat > "$DESKTOP_DIR/$APP_ID.desktop" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=KLIGHTTEN MEDIA
Comment=Linux media hub for music, YouTube, local video and ani-cli
Exec=$APP_DIR/run.sh
TryExec=$APP_DIR/run.sh
Icon=klightten-media
Terminal=false
Categories=AudioVideo;Audio;Video;Player;
StartupNotify=true
StartupWMClass=$APP_ID
X-GNOME-WMClass=$APP_ID
EOF
chmod +x "$DESKTOP_DIR/$APP_ID.desktop"
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DESKTOP_DIR" >/dev/null 2>&1 || true
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -f -t "$ICON_ROOT" >/dev/null 2>&1 || true


# Automatic legacy cleanup for replaced KLIGHTTEN builds.
# Only app-specific generated/obsolete files are touched.
rm -rf "$APP_DIR/__pycache__" "$APP_DIR/ui/__pycache__" "$APP_DIR/.pytest_cache" 2>/dev/null || true
rm -f \
  "$APP_DIR/downloader.py" \
  "$APP_DIR/download_helper.py" \
  "$APP_DIR/youtube_downloader.py" \
  "$APP_DIR/pytube_plugin.py" \
  "$APP_DIR/assets/klightten-music.svg" 2>/dev/null || true
rm -rf "$APP_DIR/plugins/pytube" "$APP_DIR/plugins/downloader" 2>/dev/null || true

# Remove harmless platform/editor leftovers when users replace builds in-place.
find "$APP_DIR" -maxdepth 3 -type f \( -name '*.pyc' -o -name '.DS_Store' -o -name 'Thumbs.db' \) -delete 2>/dev/null || true

# Pytube belonged only to the removed downloader integration. Remove it from
# KLIGHTTEN's own virtualenv automatically; never touch the system Python.
if [[ -x "$APP_DIR/.venv/bin/python" ]]; then
  if "$APP_DIR/.venv/bin/python" -m pip show pytube >/dev/null 2>&1; then
    "$APP_DIR/.venv/bin/python" -m pip uninstall -y pytube >/dev/null 2>&1 || true
  fi
fi

if [[ ! -x ".venv/bin/python" ]]; then
  echo "KLIGHTTEN MEDIA is not set up yet."
  echo "Run: ./setup.sh"
  exit 1
fi

if .venv/bin/python - <<'PY' >/dev/null 2>&1
try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
except Exception:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
PY
then
  exec .venv/bin/python qt_shell.py
else
  echo "Qt WebEngine is missing. KLIGHTTEN MEDIA needs the Chromium-based playback shell."
  echo "Run: ./setup.sh"
  exit 1
fi

# KLIGHTTEN MEDIA Branding

## Canonical logo

- Neon-Arcade color background
- black cat ears
- spaced black mark: `//  =  ^  w  ^  =  )`
- black-and-white reading waveform
- black `Klightten Media` wordmark
- no transparent background
- no headphones
- no CAVA-style waveform

Full brand: `assets/klightten-media-brand.png`

Compact Linux icon: `assets/klightten-media-icon.png`

## Canonical themes

1. Bunny — Dark-Mint
2. Cat — Neon-Arcade
3. Wolf — Black-White
4. Fox — Crimson-Red
5. Dog — Cream Coffee

# Security Policy

Do not publish OAuth tokens, cookies, credentials, private URLs or personal media paths in public issues.

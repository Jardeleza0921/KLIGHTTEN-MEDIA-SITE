local marker = os.getenv("KLIGHTTEN_MPV_KEY_MARKER")
local function emit(name) if marker==nil or marker=="" then return end local f=io.open(marker,"w") if f~=nil then f:write(name) f:close() end end
mp.add_forced_key_binding("f","klightten-mpv-fullscreen",function() emit("F") end,{repeatable=false})
mp.add_forced_key_binding("F11","klightten-app-fullscreen",function() emit("F11") end,{repeatable=false})
mp.add_forced_key_binding("Ctrl+ESC","klightten-exit",function() emit("EXIT") end,{repeatable=false})
mp.add_forced_key_binding("m","klightten-mute",function() emit("M") end,{repeatable=false})
mp.add_forced_key_binding("s","klightten-shuffle",function() emit("S") end,{repeatable=false})

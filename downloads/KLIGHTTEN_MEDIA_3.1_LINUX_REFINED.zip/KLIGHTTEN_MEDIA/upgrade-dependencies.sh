#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ "$(uname -s)" != "Linux" ]]; then echo "KLIGHTTEN MEDIA supports Linux only."; exit 1; fi
echo "KLIGHTTEN MEDIA — Download / Upgrade Dependencies"
echo
if command -v apt >/dev/null 2>&1; then
  sudo apt update
  sudo apt install -y python3 python3-venv python3-pip python3-gi mpv ffmpeg curl fzf git gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav
elif command -v pacman >/dev/null 2>&1; then
  sudo pacman -Syu --needed python python-pip python-gobject mpv ffmpeg curl fzf git gst-plugins-base gst-plugins-good gst-plugins-bad gst-plugins-ugly gst-libav
elif command -v dnf >/dev/null 2>&1; then
  echo "Fedora detected. MPV/FFmpeg may require RPM Fusion on some systems."
  sudo dnf upgrade -y
  sudo dnf install -y python3 python3-pip python3-gobject mpv ffmpeg curl fzf git gstreamer1-plugins-base gstreamer1-plugins-good gstreamer1-plugins-bad-free || true
else
  echo "Unsupported automatic package manager. Install: Python 3, Qt WebEngine, MPV, FFmpeg, GStreamer, curl, fzf and git."
fi
if [[ -x "$APP_DIR/.venv/bin/python" ]]; then "$APP_DIR/.venv/bin/python" -m pip install -U pip && "$APP_DIR/.venv/bin/python" -m pip install -U -r "$APP_DIR/requirements.txt"; fi
echo
echo "Dependencies checked/upgraded."

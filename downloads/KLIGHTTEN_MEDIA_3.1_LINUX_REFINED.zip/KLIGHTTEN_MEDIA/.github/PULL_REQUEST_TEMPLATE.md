## Summary

## Testing
- [ ] `./diagnose.sh`
- [ ] App starts
- [ ] Relevant workflow tested
- [ ] Minimize/Float/fullscreen checked

---
name: Bug report
about: Report a reproducible KLIGHTTEN MEDIA problem
title: "[BUG] "
labels: bug
---
## Environment
- Distribution:
- Desktop environment:
- Version:

## What happened?

## Steps to reproduce

## Diagnostics
Paste relevant `./diagnose.sh` output.

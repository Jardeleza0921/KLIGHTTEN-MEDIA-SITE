#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

echo "== KLIGHTTEN MEDIA 2.6 Clean Media setup =="

if command -v apt >/dev/null 2>&1; then
  echo "Installing audio and Qt WebEngine requirements..."
  sudo apt update

  BASE_PKGS=(
    python3 python3-venv python3-pip python3-gi
    gir1.2-gstreamer-1.0
    mpv ffmpeg gstreamer1.0-tools gstreamer1.0-plugins-base gstreamer1.0-plugins-good
    gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav
    gstreamer1.0-alsa gstreamer1.0-pulseaudio
  )
  sudo apt install -y "${BASE_PKGS[@]}"

  echo "KLIGHTTEN uses MPV automatically for local audio/video and ani-cli media."
  for pkg in fzf curl; do
    if apt-cache show "$pkg" >/dev/null 2>&1; then sudo apt install -y "$pkg" || true; fi
  done

  QT6_PKGS=(python3-pyqt6 python3-pyqt6.qtwebengine python3-pyqt6.qtwebchannel)
  QT5_PKGS=(python3-pyqt5 python3-pyqt5.qtwebengine python3-pyqt5.qtwebchannel)
  qt6_ok=1
  for pkg in "${QT6_PKGS[@]}"; do
    if ! apt-cache show "$pkg" >/dev/null 2>&1; then qt6_ok=0; fi
  done
  if [[ "$qt6_ok" -eq 1 ]]; then
    echo "Installing PyQt6 + Qt WebEngine..."
    sudo apt install -y "${QT6_PKGS[@]}"
  else
    qt5_ok=1
    for pkg in "${QT5_PKGS[@]}"; do
      if ! apt-cache show "$pkg" >/dev/null 2>&1; then qt5_ok=0; fi
    done
    if [[ "$qt5_ok" -eq 1 ]]; then
      echo "PyQt6 packages unavailable; installing PyQt5 + Qt WebEngine..."
      sudo apt install -y "${QT5_PKGS[@]}"
    else
      echo "No complete distro Qt WebEngine Python set found; pip fallback will be used."
    fi
  fi

  if apt-cache show chromium-codecs-ffmpeg-extra >/dev/null 2>&1; then
    sudo apt install -y chromium-codecs-ffmpeg-extra || true
  fi
else
  echo "Non-APT system detected. Install Python 3, MPV, FFmpeg, GStreamer, PyQt6/PyQt5, and Qt WebEngine."
fi

echo "Creating virtual environment..."
python3 -m venv --system-site-packages .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# Remove the old downloader experiment from KLIGHTTEN's virtual environment.
python -m pip uninstall -y pytube >/dev/null 2>&1 || true



# Prefer distro Qt WebEngine because it is usually smaller and better integrated.
if ! python - <<'PY' >/dev/null 2>&1
try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
except Exception:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
PY
then
  echo "Installing PyQt6 WebEngine from pip as fallback (this download is larger)..."
  python -m pip install 'PyQt6>=6.7,<7' 'PyQt6-WebEngine>=6.7,<7'
fi

deactivate

chmod +x run.sh diagnose.sh main.py qt_shell.py

APP_ID="io.github.jardeleza0921.klighttenmedia"
mkdir -p "$HOME/.local/share/applications"
mkdir -p "$HOME/.local/share/icons/hicolor/scalable/apps"
cp "$APP_DIR/assets/klightten-media.svg" \
   "$HOME/.local/share/icons/hicolor/scalable/apps/klightten-media.svg"

rm -f "$HOME/.local/share/applications/klightten-music.desktop" "$HOME/.local/share/applications/io.github.jardeleza0921.klighttenmusic.desktop"
cat > "$HOME/.local/share/applications/$APP_ID.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=KLIGHTTEN MEDIA
Comment=KLIGHTTEN media player with local audio and YouTube video playback
Exec=$APP_DIR/run.sh
Icon=klightten-music
Terminal=false
Categories=AudioVideo;Audio;Video;Player;
StartupNotify=true
StartupWMClass=$APP_ID
EOF
chmod +x "$HOME/.local/share/applications/$APP_ID.desktop"

echo
echo "Setup complete."
if command -v ani-cli >/dev/null 2>&1; then echo "ani-cli plugin: detected at $(command -v ani-cli)"; else echo "ani-cli plugin: not installed (add it later in Settings > Plugins)"; fi
echo "Playback shell: Qt WebEngine / Chromium"
echo "YouTube app ID: $APP_ID"
echo "Run with: $APP_DIR/run.sh"

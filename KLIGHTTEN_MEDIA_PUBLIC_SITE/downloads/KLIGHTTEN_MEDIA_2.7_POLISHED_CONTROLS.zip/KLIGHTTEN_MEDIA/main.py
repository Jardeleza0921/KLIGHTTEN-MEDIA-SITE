#!/usr/bin/env python3
from __future__ import annotations

import base64
import html
import json
import mimetypes
import os
import re
import sys
import webbrowser
import shutil
import shlex
import socket
import subprocess
import tempfile
import time
import threading
import pty
import select
import errno
import uuid
import fcntl
import termios
import struct
from datetime import datetime, timezone
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse
from urllib.request import Request, urlopen

try:
    import webview
except ImportError:
    webview = None

GST_AVAILABLE = False
GST_IMPORT_ERROR = ''
try:
    import gi
    gi.require_version('Gst', '1.0')
    from gi.repository import Gst
    GST_AVAILABLE = True
except Exception as exc:
    Gst = None
    GST_IMPORT_ERROR = str(exc)

try:
    from mutagen import File as MutagenFile
except ImportError:
    MutagenFile = None

VLC_AVAILABLE = False
VLC_IMPORT_ERROR = ''
try:
    import vlc
    VLC_AVAILABLE = True
except Exception as exc:
    vlc = None
    VLC_IMPORT_ERROR = str(exc)

PYTE_AVAILABLE = False
PYTE_IMPORT_ERROR = ''
try:
    import pyte
    PYTE_AVAILABLE = True
except Exception as exc:
    pyte = None
    PYTE_IMPORT_ERROR = str(exc)

GOOGLE_AUTH_AVAILABLE = False
GOOGLE_AUTH_IMPORT_ERROR = ''
try:
    from google.oauth2.credentials import Credentials as GoogleCredentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from google.auth.transport.requests import Request as GoogleAuthRequest
    GOOGLE_AUTH_AVAILABLE = True
except Exception as exc:
    GoogleCredentials = None
    InstalledAppFlow = None
    GoogleAuthRequest = None
    GOOGLE_AUTH_IMPORT_ERROR = str(exc)

APP_NAME = 'KLIGHTTEN MEDIA'
APP_VERSION = '2.7.0'
YOUTUBE_APP_ID = 'io.github.jardeleza0921.klighttenmedia'
YOUTUBE_REFERER = f'https://{YOUTUBE_APP_ID}/'
BASE_DIR = Path(__file__).resolve().parent
UI_FILE = BASE_DIR / 'ui' / 'index.html'
LEGACY_CONFIG_DIR = Path.home() / '.config' / 'klightten-music'
CONFIG_DIR = Path.home() / '.config' / 'klightten-media'
CONFIG_FILE = CONFIG_DIR / 'config.json'
STATE_FILE = CONFIG_DIR / 'state.json'
OAUTH_CLIENT_FILE = CONFIG_DIR / 'youtube_oauth_client.json'
OAUTH_TOKEN_FILE = CONFIG_DIR / 'youtube_oauth_token.json'
OAUTH_ACCOUNTS_DIR = CONFIG_DIR / 'youtube_accounts'
ANIME_HISTORY_FILE = CONFIG_DIR / 'anime_history.json'
ANI_CAPTURE_DIR = CONFIG_DIR / 'ani-capture'
YOUTUBE_READONLY_SCOPE = ['https://www.googleapis.com/auth/youtube.readonly']
AUDIO_EXTENSIONS = {'.mp3', '.wav', '.ogg', '.oga', '.flac', '.m4a', '.aac', '.opus', '.wma'}
VIDEO_EXTENSIONS = {'.mp4', '.mkv', '.webm', '.mov', '.avi', '.m4v', '.mpeg', '.mpg', '.ts', '.flv', '.wmv'}
MEDIA_EXTENSIONS = AUDIO_EXTENSIONS | VIDEO_EXTENSIONS
CONVERTER_DEFAULT_DIR = Path.home() / 'Music' / 'KLIGHTTEN Converts'
PROFILE_IMAGE_MAX_BYTES = 4_000_000
MAX_LIBRARY_TRACKS = 5000
MAX_VIDEO_FILES = 2000
MAX_HISTORY = 100
MAX_STATE_QUEUE = 500
MAX_ART_BYTES = 2_000_000


def _cleanup_legacy_install() -> None:
    """Remove obsolete KLIGHTTEN-only files/state from older builds.

    Never deletes user media, converted outputs, OAuth credentials, playlists,
    libraries, favorites, history, or system packages.
    """
    try:
        # Generated Python caches are safe to recreate and should not remain
        # when users replace one KLIGHTTEN build with another.
        for cache_dir in (
            BASE_DIR / '__pycache__',
            BASE_DIR / 'ui' / '__pycache__',
            BASE_DIR / '.pytest_cache',
        ):
            if cache_dir.exists() and cache_dir.is_dir():
                shutil.rmtree(cache_dir, ignore_errors=True)

        # Known app-internal downloader files/folders from experimental builds.
        obsolete_paths = (
            BASE_DIR / 'downloader.py',
            BASE_DIR / 'download_helper.py',
            BASE_DIR / 'youtube_downloader.py',
            BASE_DIR / 'pytube_plugin.py',
            BASE_DIR / 'plugins' / 'pytube',
            BASE_DIR / 'plugins' / 'downloader',
            CONFIG_DIR / 'download_jobs.json',
            CONFIG_DIR / 'download_history.json',
            CONFIG_DIR / 'downloader.json',
            CONFIG_DIR / 'pytube.json',
            CONFIG_DIR / 'pytube_state.json',
        )
        for path in obsolete_paths:
            try:
                if path.is_dir():
                    shutil.rmtree(path, ignore_errors=True)
                elif path.exists():
                    path.unlink(missing_ok=True)
            except Exception:
                pass

        # Clean obsolete settings without touching current user configuration.
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
            except Exception:
                data = None
            if isinstance(data, dict):
                obsolete_keys = {
                    'player_backend',
                    'download_folder',
                    'download_output_folder',
                    'downloader',
                    'download_history',
                    'pytube',
                    'pytube_enabled',
                    'pytube_version',
                }
                changed = False
                for key in obsolete_keys:
                    if key in data:
                        data.pop(key, None)
                        changed = True
                if changed:
                    CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding='utf-8')
                    try:
                        os.chmod(CONFIG_FILE, 0o600)
                    except OSError:
                        pass
    except Exception:
        # Cleanup must never prevent KLIGHTTEN from starting.
        pass

def _migrate_legacy_config() -> None:
    """One-time migration from KLIGHTTEN MEDIA so updates keep user data."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if not LEGACY_CONFIG_DIR.exists():
            return
        for name in ('config.json', 'state.json', 'youtube_oauth_client.json', 'youtube_oauth_token.json'):
            old = LEGACY_CONFIG_DIR / name
            new = CONFIG_DIR / name
            if old.exists() and not new.exists():
                shutil.copy2(old, new)
    except Exception:
        pass

_cleanup_legacy_install()
_migrate_legacy_config()


if GST_AVAILABLE:
    Gst.init(None)


class MPVAudioEngine:
    """Local-only audio backend using mpv JSON IPC."""
    def __init__(self) -> None:
        self.mpv = shutil.which('mpv')
        if not self.mpv:
            raise RuntimeError('mpv is not installed.')
        self.socket_path = str(Path(tempfile.gettempdir()) / f'klightten-music-{os.getpid()}.sock')
        self.process = None
        self.current_path: str | None = None
        self.current_uri: str | None = None
        self.volume = 0.70
        self._eos_seen = False
        self._last_error = ''

    def _ensure_started(self) -> None:
        if self.process is not None and self.process.poll() is None and Path(self.socket_path).exists():
            return
        self.shutdown()
        try:
            Path(self.socket_path).unlink(missing_ok=True)
        except Exception:
            pass
        cmd = [
            self.mpv,
            '--idle=yes',
            '--no-video',
            '--volume-max=200',
            '--audio-display=no',
            '--force-window=no',
            '--input-terminal=no',
            '--really-quiet',
            '--keep-open=yes',
            f'--input-ipc-server={self.socket_path}',
            f'--volume={round(self.volume * 100)}',
        ]
        self.process = subprocess.Popen(
            cmd,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        deadline = time.time() + 2.5
        while time.time() < deadline:
            if self.process.poll() is not None:
                raise RuntimeError('mpv exited before its audio service started.')
            if Path(self.socket_path).exists():
                return
            time.sleep(0.04)
        raise RuntimeError('mpv audio service did not start.')

    def _command(self, command: list, timeout: float = 1.0):
        self._ensure_started()
        payload = json.dumps({'command': command}).encode('utf-8') + b'\n'
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                sock.connect(self.socket_path)
                sock.sendall(payload)
                data = b''
                while b'\n' not in data:
                    chunk = sock.recv(65536)
                    if not chunk:
                        break
                    data += chunk
            if not data:
                return {'error': 'empty response'}
            response = json.loads(data.split(b'\n', 1)[0].decode('utf-8', errors='replace'))
            if response.get('error') != 'success':
                self._last_error = str(response.get('error') or 'mpv command failed')
            return response
        except Exception as exc:
            self._last_error = str(exc)
            return {'error': str(exc)}

    def _get(self, name: str, default=None):
        response = self._command(['get_property', name])
        if response.get('error') == 'success':
            return response.get('data', default)
        return default

    def load(self, path: str, autoplay: bool = True) -> dict:
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists() or not file_path.is_file():
            return {'ok': False, 'error': 'Audio file not found.'}
        if file_path.suffix.lower() not in AUDIO_EXTENSIONS:
            return {'ok': False, 'error': 'Unsupported audio file type.'}
        try:
            self._ensure_started()
            self._command(['set_property', 'pause', not bool(autoplay)])
            response = self._command(['loadfile', str(file_path), 'replace'])
            if response.get('error') != 'success':
                return {'ok': False, 'error': f"mpv could not open the file: {response.get('error', 'unknown error')}"}
            self.current_path = str(file_path)
            self.current_uri = file_path.as_uri()
            self._eos_seen = False
            self._last_error = ''
            self._command(['set_property', 'volume', round(self.volume * 100)])
            self._command(['set_property', 'pause', not bool(autoplay)])
            return {'ok': True, 'track': read_audio_metadata(file_path), 'backend': 'mpv'}
        except Exception as exc:
            return {'ok': False, 'error': f'mpv playback failed: {exc}'}

    def play(self) -> dict:
        if not self.current_path:
            return {'ok': False, 'error': 'No audio file loaded.'}
        self._eos_seen = False
        r = self._command(['set_property', 'pause', False])
        return {'ok': r.get('error') == 'success', 'error': '' if r.get('error') == 'success' else str(r.get('error'))}

    def pause(self) -> dict:
        if not self.current_path:
            return {'ok': False, 'error': 'No audio file loaded.'}
        r = self._command(['set_property', 'pause', True])
        return {'ok': r.get('error') == 'success'}

    def toggle(self) -> dict:
        if not self.current_path:
            return {'ok': False, 'error': 'No audio file loaded.'}
        paused = bool(self._get('pause', False))
        r = self._command(['set_property', 'pause', not paused])
        if r.get('error') != 'success':
            return {'ok': False, 'error': str(r.get('error'))}
        if paused:
            self._eos_seen = False
        return {'ok': True, 'playing': paused}

    def stop(self) -> dict:
        if self.process is not None and self.process.poll() is None:
            self._command(['stop'])
        self.current_path = None
        self.current_uri = None
        self._eos_seen = False
        return {'ok': True}

    def set_volume(self, percent: float) -> dict:
        try:
            value = max(0.0, min(200.0, float(percent)))
        except (TypeError, ValueError):
            value = 70.0
        self.volume = value / 100.0
        if self.process is not None and self.process.poll() is None:
            self._command(['set_property', 'volume', value])
        return {'ok': True, 'volume': round(value)}

    def seek(self, seconds: float) -> dict:
        if not self.current_path:
            return {'ok': False, 'error': 'No audio file loaded.'}
        try:
            seconds = max(0.0, float(seconds))
        except (TypeError, ValueError):
            return {'ok': False, 'error': 'Invalid seek position.'}
        r = self._command(['seek', seconds, 'absolute', 'exact'])
        return {'ok': r.get('error') == 'success'}

    def seek_relative(self, delta_seconds: float) -> dict:
        if not self.current_path:
            return {'ok': False, 'error': 'No audio file loaded.'}
        try:
            delta = float(delta_seconds)
        except (TypeError, ValueError):
            return {'ok': False, 'error': 'Invalid seek amount.'}
        r = self._command(['seek', delta, 'relative', 'exact'])
        return {'ok': r.get('error') == 'success'}

    def set_sound_preset(self, preset: str) -> dict:
        preset = str(preset or 'flat').lower()
        filters = {
            'flat': '',
            'bass': 'lavfi=[equalizer=f=110:t=q:w=1:g=5]',
            'voice': 'lavfi=[equalizer=f=3200:t=q:w=1:g=4]',
            'night': 'lavfi=[acompressor=threshold=-18dB:ratio=3:attack=20:release=250]',
        }
        if preset not in filters:
            preset = 'flat'
        if self.process is not None and self.process.poll() is None:
            response = self._command(['set_property', 'af', filters[preset]])
            if response.get('error') != 'success':
                return {'ok': False, 'error': str(response.get('error')), 'preset': preset}
        return {'ok': True, 'preset': preset}

    def status(self) -> dict:
        if not self.current_path:
            return {'ok': True, 'playing': False, 'state': 'idle', 'position': 0.0, 'duration': 0.0,
                    'volume': round(self.volume * 100), 'eos': False, 'error': self._last_error, 'backend': 'mpv'}
        if self.process is None or self.process.poll() is not None:
            return {'ok': False, 'playing': False, 'state': 'error', 'position': 0.0, 'duration': 0.0,
                    'volume': round(self.volume * 100), 'eos': False, 'error': 'mpv stopped unexpectedly.', 'backend': 'mpv'}
        paused = bool(self._get('pause', False))
        position = float(self._get('time-pos', 0.0) or 0.0)
        duration = float(self._get('duration', 0.0) or 0.0)
        eof = bool(self._get('eof-reached', False))
        eos = False
        if eof and not self._eos_seen:
            eos = True
            self._eos_seen = True
        elif not eof:
            self._eos_seen = False
        state = 'ended' if eof else ('paused' if paused else 'playing')
        return {'ok': True, 'playing': (not paused and not eof), 'state': state, 'position': round(position, 3),
                'duration': round(duration, 3), 'volume': round(self.volume * 100), 'eos': eos,
                'error': self._last_error, 'backend': 'mpv'}

    def shutdown(self) -> None:
        proc = self.process
        self.process = None
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        try:
            Path(self.socket_path).unlink(missing_ok=True)
        except Exception:
            pass


class GStreamerAudioEngine:
    def __init__(self) -> None:
        if not GST_AVAILABLE:
            raise RuntimeError('GStreamer Python bindings are unavailable: ' + GST_IMPORT_ERROR)
        self.player = Gst.ElementFactory.make('playbin', 'player')
        if self.player is None:
            raise RuntimeError('Could not create GStreamer playbin.')
        self.current_path: str | None = None
        self.current_uri: str | None = None
        self.volume = 0.70
        self.player.set_property('volume', self.volume)
        self._eos_seen = False

    def load(self, path: str, autoplay: bool = True) -> dict:
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists() or not file_path.is_file():
            return {'ok': False, 'error': 'Audio file not found.'}
        if file_path.suffix.lower() not in AUDIO_EXTENSIONS:
            return {'ok': False, 'error': 'Unsupported audio file type.'}
        self.stop()
        self.current_path = str(file_path)
        self.current_uri = file_path.as_uri()
        self.player.set_property('uri', self.current_uri)
        self.player.set_property('volume', self.volume)
        self._eos_seen = False
        self.player.set_state(Gst.State.PLAYING if autoplay else Gst.State.PAUSED)
        return {'ok': True, 'track': read_audio_metadata(file_path)}

    def play(self) -> dict:
        if not self.current_uri:
            return {'ok': False, 'error': 'No audio file loaded.'}
        self._eos_seen = False
        self.player.set_state(Gst.State.PLAYING)
        return {'ok': True}

    def pause(self) -> dict:
        if not self.current_uri:
            return {'ok': False, 'error': 'No audio file loaded.'}
        self.player.set_state(Gst.State.PAUSED)
        return {'ok': True}

    def toggle(self) -> dict:
        if not self.current_uri:
            return {'ok': False, 'error': 'No audio file loaded.'}
        _, state, _ = self.player.get_state(0)
        if state == Gst.State.PLAYING:
            self.player.set_state(Gst.State.PAUSED)
            return {'ok': True, 'playing': False}
        self._eos_seen = False
        self.player.set_state(Gst.State.PLAYING)
        return {'ok': True, 'playing': True}

    def stop(self) -> dict:
        self.player.set_state(Gst.State.NULL)
        return {'ok': True}

    def set_volume(self, percent: float) -> dict:
        try:
            value = max(0.0, min(200.0, float(percent)))
        except (TypeError, ValueError):
            value = 70.0
        self.volume = value / 100.0
        self.player.set_property('volume', self.volume)
        return {'ok': True, 'volume': round(value)}

    def seek(self, seconds: float) -> dict:
        if not self.current_uri:
            return {'ok': False, 'error': 'No audio file loaded.'}
        try:
            seconds = max(0.0, float(seconds))
        except (TypeError, ValueError):
            return {'ok': False, 'error': 'Invalid seek position.'}
        ok = self.player.seek_simple(
            Gst.Format.TIME,
            Gst.SeekFlags.FLUSH | Gst.SeekFlags.KEY_UNIT,
            int(seconds * Gst.SECOND),
        )
        return {'ok': bool(ok)}

    def seek_relative(self, delta_seconds: float) -> dict:
        status = self.status()
        position = status.get('position', 0.0)
        duration = status.get('duration', 0.0)
        target = max(0.0, position + float(delta_seconds))
        if duration > 0:
            target = min(duration, target)
        return self.seek(target)

    def status(self) -> dict:
        playing = False
        state_name = 'idle'
        position = 0.0
        duration = 0.0
        eos = False
        error_message = ''
        if self.current_uri:
            _, state, _ = self.player.get_state(0)
            if state == Gst.State.PLAYING:
                playing = True
                state_name = 'playing'
            elif state == Gst.State.PAUSED:
                state_name = 'paused'
            elif state == Gst.State.READY:
                state_name = 'ready'
            else:
                state_name = 'stopped'
            ok_pos, pos = self.player.query_position(Gst.Format.TIME)
            ok_dur, dur = self.player.query_duration(Gst.Format.TIME)
            if ok_pos and pos >= 0:
                position = pos / Gst.SECOND
            if ok_dur and dur > 0:
                duration = dur / Gst.SECOND
            bus = self.player.get_bus()
            while True:
                msg = bus.pop_filtered(Gst.MessageType.EOS | Gst.MessageType.ERROR)
                if msg is None:
                    break
                if msg.type == Gst.MessageType.EOS:
                    if not self._eos_seen:
                        eos = True
                        self._eos_seen = True
                        self.player.set_state(Gst.State.PAUSED)
                        state_name = 'ended'
                        playing = False
                elif msg.type == Gst.MessageType.ERROR:
                    err, _debug = msg.parse_error()
                    error_message = str(err)
                    state_name = 'error'
                    playing = False
        return {
            'ok': True,
            'playing': playing,
            'state': state_name,
            'position': round(position, 3),
            'duration': round(duration, 3),
            'volume': round(self.volume * 100),
            'eos': eos,
            'error': error_message,
            'backend': 'gstreamer',
        }

    def set_sound_preset(self, preset: str) -> dict:
        # GStreamer fallback keeps a neutral pipeline; advanced presets are MPV/VLC features.
        return {'ok': True, 'preset': str(preset or 'flat').lower(), 'limited': True}

    def shutdown(self) -> None:
        try:
            self.player.set_state(Gst.State.NULL)
        except Exception:
            pass


class VLCAudioEngine:
    """Integrated local-audio backend using libVLC."""
    def __init__(self) -> None:
        if not VLC_AVAILABLE:
            raise RuntimeError('python-vlc is unavailable: ' + VLC_IMPORT_ERROR)
        self.instance = vlc.Instance('--no-video-title-show', '--quiet')
        self.player = self.instance.media_player_new()
        self.current_path = None
        self.volume = 0.70
        self._eos_seen = False

    def load(self, path: str, autoplay: bool = True) -> dict:
        file_path = Path(path).expanduser().resolve()
        if not file_path.exists() or file_path.suffix.lower() not in AUDIO_EXTENSIONS:
            return {'ok': False, 'error': 'Unsupported or missing local audio file.'}
        media = self.instance.media_new(str(file_path))
        self.player.set_media(media)
        self.player.audio_set_volume(round(self.volume * 100))
        self.current_path = str(file_path)
        self._eos_seen = False
        if autoplay:
            self.player.play()
        else:
            self.player.play(); time.sleep(0.05); self.player.set_pause(1)
        return {'ok': True, 'track': read_audio_metadata(file_path), 'backend': 'vlc'}

    def play(self):
        if not self.current_path: return {'ok': False, 'error': 'No audio file loaded.'}
        self._eos_seen = False; self.player.play(); return {'ok': True}
    def pause(self):
        if not self.current_path: return {'ok': False, 'error': 'No audio file loaded.'}
        self.player.set_pause(1); return {'ok': True}
    def toggle(self):
        if not self.current_path: return {'ok': False, 'error': 'No audio file loaded.'}
        playing = bool(self.player.is_playing())
        self.player.set_pause(1 if playing else 0)
        return {'ok': True, 'playing': not playing}
    def stop(self):
        self.player.stop(); self.current_path=None; self._eos_seen=False; return {'ok': True}
    def set_volume(self, percent):
        try: value=max(0.0,min(100.0,float(percent)))
        except Exception: value=70.0
        self.volume=value/100.0; self.player.audio_set_volume(round(value)); return {'ok': True,'volume':round(value)}
    def seek(self, seconds):
        try: ms=max(0,int(float(seconds)*1000))
        except Exception: return {'ok':False,'error':'Invalid seek position.'}
        return {'ok': self.player.set_time(ms) != -1}
    def seek_relative(self, delta_seconds):
        return self.seek(max(0.0, self.player.get_time()/1000.0 + float(delta_seconds)))
    def status(self):
        if not self.current_path:
            return {'ok':True,'playing':False,'state':'idle','position':0.0,'duration':0.0,'volume':round(self.volume*100),'eos':False,'error':'','backend':'vlc'}
        state=self.player.get_state(); playing=bool(self.player.is_playing()); pos=max(0,self.player.get_time())/1000.0; dur=max(0,self.player.get_length())/1000.0
        ended = str(state).lower().endswith('ended')
        eos = ended and not self._eos_seen
        self._eos_seen = ended
        return {'ok':True,'playing':playing,'state':'ended' if ended else ('playing' if playing else 'paused'),'position':round(pos,3),'duration':round(dur,3),'volume':round(self.volume*100),'eos':eos,'error':'','backend':'vlc'}
    def set_sound_preset(self, preset: str):
        preset=str(preset or 'flat').lower()
        try:
            eq=vlc.AudioEqualizer()
            gains={'flat':(0,0),'bass':(5,0),'voice':(0,4),'night':(1,1)}
            low,mid=gains.get(preset,(0,0))
            count=eq.get_amp_at_index.__self__.get_band_count() if False else 10
            # Common libVLC equalizer bands; gracefully ignore unsupported calls.
            for i in range(count):
                hz = vlc.libvlc_audio_equalizer_get_band_frequency(i)
                gain = low if hz < 250 else (mid if 1800 < hz < 5000 else 0)
                eq.set_amp_at_index(float(gain), i)
            self.player.set_equalizer(eq)
        except Exception:
            pass
        return {'ok':True,'preset':preset}
    def shutdown(self):
        try: self.player.stop()
        except Exception: pass



class PlayerctlAudioEngine:
    """MPRIS bridge controlled from KLIGHTTEN through playerctl."""
    def __init__(self) -> None:
        self.playerctl = shutil.which('playerctl')
        if not self.playerctl:
            raise RuntimeError('playerctl is not installed.')
        self.current_path = None
        self.volume = 0.70
        self.player_name = self._find_player()

    def _find_player(self):
        try:
            out = subprocess.run([self.playerctl, '-l'], capture_output=True, text=True, timeout=3).stdout.splitlines()
            return out[0].strip() if out else ''
        except Exception:
            return ''

    def _ctl(self, *args):
        if not self.player_name:
            self.player_name = self._find_player()
        if not self.player_name:
            return None
        try:
            return subprocess.run([self.playerctl, '-p', self.player_name, *map(str,args)], capture_output=True, text=True, timeout=4)
        except Exception:
            return None

    def load(self, path: str, autoplay: bool = True) -> dict:
        f = Path(path).expanduser().resolve()
        if not f.exists():
            return {'ok': False, 'error': 'Media file not found.'}
        if not self.player_name:
            self.player_name = self._find_player()
        if not self.player_name:
            return {'ok': False, 'error': 'No MPRIS media player is currently available for playerctl.'}
        r = self._ctl('open', f.as_uri())
        if r is None or r.returncode != 0:
            return {'ok': False, 'error': 'The selected MPRIS player did not accept this file.'}
        self.current_path = str(f)
        self.set_volume(self.volume * 100)
        if autoplay:
            self.play()
        else:
            self.pause()
        return {'ok': True, 'track': read_audio_metadata(f) if f.suffix.lower() in AUDIO_EXTENSIONS else {'title': f.stem, 'path': str(f)}, 'backend': 'playerctl'}

    def play(self): 
        r=self._ctl('play'); return {'ok': bool(r is not None and r.returncode==0)}
    def pause(self):
        r=self._ctl('pause'); return {'ok': bool(r is not None and r.returncode==0)}
    def toggle(self):
        r=self._ctl('play-pause'); return {'ok': bool(r is not None and r.returncode==0)}
    def stop(self):
        r=self._ctl('stop'); self.current_path=None; return {'ok': bool(r is not None)}
    def set_volume(self, percent):
        try: v=max(0,min(200,float(percent)))
        except Exception: v=70
        self.volume=v/100
        self._ctl('volume', min(1.0,self.volume))
        return {'ok':True,'volume':round(v),'limited':v>100}
    def seek(self, seconds):
        r=self._ctl('position', max(0,float(seconds))); return {'ok': bool(r is not None and r.returncode==0)}
    def seek_relative(self, delta_seconds):
        try: d=float(delta_seconds)
        except Exception: return {'ok':False,'error':'Invalid seek amount.'}
        token=f'{abs(d):g}' + ('+' if d>=0 else '-')
        r=self._ctl('position', token); return {'ok': bool(r is not None and r.returncode==0)}
    def status(self):
        if not self.current_path:
            return {'ok':True,'playing':False,'state':'idle','position':0,'duration':0,'volume':round(self.volume*100),'eos':False,'error':'','backend':'playerctl'}
        st=self._ctl('status'); pos=self._ctl('position')
        playing=bool(st and st.stdout.strip().lower()=='playing')
        try: p=float(pos.stdout.strip()) if pos else 0
        except Exception: p=0
        return {'ok':True,'playing':playing,'state':'playing' if playing else 'paused','position':p,'duration':0,'volume':round(self.volume*100),'eos':False,'error':'','backend':'playerctl','player':self.player_name}
    def set_sound_preset(self,preset): return {'ok':True,'preset':str(preset or 'flat'),'limited':True}
    def shutdown(self): pass


class CelluloidAudioEngine:
    """External Celluloid frontend controlled through MPRIS/playerctl when available."""
    def __init__(self) -> None:
        self.binary = shutil.which('celluloid')
        self.playerctl = shutil.which('playerctl')
        if not self.binary:
            raise RuntimeError('Celluloid is not installed.')
        self.process = None; self.current_path=None; self.volume=0.70
    def _ctl(self,*args):
        if not self.playerctl: return None
        names=subprocess.run([self.playerctl,'-l'],capture_output=True,text=True).stdout.splitlines()
        name=next((n for n in names if 'celluloid' in n.lower()), None)
        if not name: return None
        return subprocess.run([self.playerctl,'-p',name,*map(str,args)],capture_output=True,text=True)
    def load(self,path,autoplay=True):
        f=Path(path).expanduser().resolve()
        if not f.exists(): return {'ok':False,'error':'Audio file not found.'}
        self.process=subprocess.Popen([self.binary,str(f)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
        self.current_path=str(f); time.sleep(.25)
        if not autoplay: self.pause()
        self.set_volume(self.volume*100)
        return {'ok':True,'track':read_audio_metadata(f),'backend':'celluloid'}
    def play(self):
        r=self._ctl('play'); return {'ok':r is not None}
    def pause(self):
        r=self._ctl('pause'); return {'ok':r is not None}
    def toggle(self):
        r=self._ctl('play-pause'); return {'ok':r is not None}
    def stop(self):
        r=self._ctl('stop'); self.current_path=None; return {'ok':True}
    def set_volume(self,percent):
        try:v=max(0,min(200,float(percent)))
        except Exception:v=70
        self.volume=v/100; self._ctl('volume',self.volume); return {'ok':True,'volume':round(v)}
    def seek(self,seconds):
        if not self.current_path:return {'ok':False,'error':'No audio file loaded.'}
        r=self._ctl('position',float(seconds)); return {'ok':r is not None}
    def seek_relative(self,delta_seconds):
        try:
            delta=float(delta_seconds)
        except Exception:
            return {'ok':False,'error':'Invalid seek amount.'}
        token=f'{abs(delta):g}' + ('+' if delta >= 0 else '-')
        r=self._ctl('position',token); return {'ok':r is not None}
    def status(self):
        if not self.current_path:return {'ok':True,'playing':False,'state':'idle','position':0,'duration':0,'volume':round(self.volume*100),'eos':False,'error':'','backend':'celluloid'}
        status=self._ctl('status'); pos=self._ctl('position'); playing=bool(status and status.stdout.strip().lower()=='playing')
        try:p=float(pos.stdout.strip()) if pos else 0.0
        except Exception:p=0.0
        return {'ok':True,'playing':playing,'state':'playing' if playing else 'paused','position':p,'duration':0,'volume':round(self.volume*100),'eos':False,'error':'','backend':'celluloid'}
    def set_sound_preset(self,preset): return {'ok':True,'preset':str(preset or 'flat'),'limited':True}
    def shutdown(self): pass


def _first_tag(tags, key: str, default: str = '') -> str:
    try:
        value = tags.get(key)
        if not value:
            return default
        if isinstance(value, (list, tuple)):
            value = value[0] if value else default
        return str(value).strip() or default
    except Exception:
        return default


def _art_data_url(path: Path) -> str:
    if MutagenFile is None:
        return ''
    try:
        raw = MutagenFile(str(path), easy=False)
        if raw is None:
            return ''
        data = None
        mime = 'image/jpeg'
        pictures = getattr(raw, 'pictures', None)
        if pictures:
            pic = pictures[0]
            data = getattr(pic, 'data', None)
            mime = getattr(pic, 'mime', None) or mime
        tags = getattr(raw, 'tags', None)
        if data is None and tags:
            # ID3 APIC
            for key in tags.keys():
                if str(key).startswith('APIC'):
                    pic = tags[key]
                    data = getattr(pic, 'data', None)
                    mime = getattr(pic, 'mime', None) or mime
                    break
            # MP4 cover art
            if data is None:
                covers = tags.get('covr') if hasattr(tags, 'get') else None
                if covers:
                    cover = covers[0]
                    data = bytes(cover)
                    imageformat = getattr(cover, 'imageformat', None)
                    if str(imageformat).endswith('14'):
                        mime = 'image/png'
        if not data or len(data) > MAX_ART_BYTES:
            return ''
        return f'data:{mime};base64,' + base64.b64encode(data).decode('ascii')
    except Exception:
        return ''


def read_audio_metadata(path: Path, include_art: bool = True) -> dict:
    path = path.expanduser().resolve()
    title = path.stem
    artist = 'Local audio'
    album = ''
    duration = 0.0
    if MutagenFile is not None:
        try:
            audio = MutagenFile(str(path), easy=True)
            if audio is not None:
                tags = audio.tags or {}
                title = _first_tag(tags, 'title', title)
                artist = _first_tag(tags, 'artist', artist)
                album = _first_tag(tags, 'album', '')
                info = getattr(audio, 'info', None)
                if info is not None:
                    duration = float(getattr(info, 'length', 0.0) or 0.0)
        except Exception:
            pass
    return {
        'id': f'local:{path}',
        'kind': 'local',
        'path': str(path),
        'filename': path.name,
        'title': title,
        'artist': artist,
        'album': album,
        'duration': round(duration, 3),
        'extension': path.suffix.lower().lstrip('.').upper(),
        'source': 'Local',
        'artwork': _art_data_url(path) if include_art else '',
    }


def _compact_track(track: dict) -> dict:
    if not isinstance(track, dict):
        return {}
    allowed = {
        'id', 'kind', 'path', 'filename', 'title', 'artist', 'album', 'duration',
        'extension', 'source', 'artwork', 'video_id', 'channel', 'thumbnail', 'url', 'media_type'
    }
    clean = {k: track.get(k) for k in allowed if k in track}
    # Do not persist huge embedded artwork inside state.json; it can be regenerated for local files.
    if isinstance(clean.get('artwork'), str) and clean['artwork'].startswith('data:'):
        clean['artwork'] = ''
    return clean


class AppAPI:
    def __init__(self) -> None:
        self.window = None
        self._maximized = False
        self._floating_video = False
        self._floating_geometry = None
        self._config = self._load_config()
        self._conversion_jobs = {}
        self._conversion_processes = {}
        self._conversion_lock = threading.RLock()
        self.audio_backend = 'none'
        self.audio_backend_error = ''
        self.audio = None
        self._ani_process = None
        self._ani_master_fd = None
        self._ani_session = None
        self._ani_last_capture = ''
        self._ani_screen = None
        self._ani_stream = None
        self._ani_raw_buffer = ''
        self.runtime_media_referrer_setter = None
        self._init_audio_backend('auto')

    def _init_audio_backend(self, choice: str = 'auto') -> dict:
        """Automatically choose the best local audio backend.

        MPV is the canonical KLIGHTTEN media engine. GStreamer is retained only
        as an emergency audio fallback if MPV is unavailable.
        """
        errors = []
        old = self.audio
        if old is not None and hasattr(old, 'shutdown'):
            try:
                old.shutdown()
            except Exception:
                pass

        self.audio = None
        self.audio_backend = 'none'
        self.audio_backend_error = ''

        for name, cls in (('mpv', MPVAudioEngine), ('gstreamer', GStreamerAudioEngine)):
            try:
                self.audio = cls()
                self.audio_backend = name
                self.audio.set_volume(self._config.get('volume', 70))
                if hasattr(self.audio, 'set_sound_preset'):
                    self.audio.set_sound_preset(self._config.get('sound_preset', 'flat'))
                self.audio_backend_error = '; '.join(errors)
                return {
                    'ok': True,
                    'backend': name,
                    'automatic': True,
                    'fallback': name != 'mpv',
                    'warning': self.audio_backend_error,
                }
            except Exception as exc:
                errors.append(f'{name}: {exc}')

        self.audio_backend_error = '; '.join(errors)
        return {'ok': False, 'backend': 'none', 'automatic': True, 'error': self.audio_backend_error}

    def select_player_backend(self, backend: str = 'auto') -> dict:
        """Legacy compatibility endpoint.

        The manual engine selector was removed in 2.5. KLIGHTTEN now chooses
        MPV automatically and falls back to GStreamer only for local audio.
        """
        return self._init_audio_backend('auto')

    def _profile_picture_data(self) -> str:
        raw=str(self._config.get('profile_picture','') or '').strip()
        if not raw: return ''
        path=Path(raw).expanduser()
        try:
            if not path.exists() or not path.is_file() or path.stat().st_size > PROFILE_IMAGE_MAX_BYTES: return ''
            mime=mimetypes.guess_type(path.name)[0] or 'image/png'
            return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode('ascii')
        except Exception:
            return ''

    def choose_profile_picture(self) -> dict:
        if not self.window: return {'ok':False,'error':'Window is not ready.'}
        try:
            paths=self.window.create_file_dialog(None,allow_multiple=False,file_types=('Images (*.png;*.jpg;*.jpeg;*.webp)','All Files (*.*)'),title='Choose profile picture')
        except Exception as exc:
            return {'ok':False,'error':f'Image picker failed: {exc}'}
        if not paths: return {'ok':True,'cancelled':True}
        path=Path(str(paths[0])).expanduser().resolve()
        if path.suffix.lower() not in {'.png','.jpg','.jpeg','.webp'}: return {'ok':False,'error':'Choose a PNG, JPG, JPEG, or WEBP image.'}
        if path.stat().st_size > PROFILE_IMAGE_MAX_BYTES: return {'ok':False,'error':'Profile image must be 4 MB or smaller.'}
        self._config['profile_picture']=str(path); self._save_config()
        return {'ok':True,'profile_picture_data':self._profile_picture_data(),'path':str(path)}

    def save_profile(self, name: str) -> dict:
        name=re.sub(r'\s+',' ',str(name or '').strip())[:40]
        if not name: return {'ok':False,'error':'Enter a profile name.'}
        self._config['profile_name']=name; self._save_config()
        return {'ok':True,'profile_name':name,'profile_picture_data':self._profile_picture_data()}

    def clear_profile_picture(self) -> dict:
        self._config['profile_picture']=''; self._save_config(); return {'ok':True}

    def save_floating_size(self, width: int, height: int) -> dict:
        try:
            width=max(360,min(1400,int(width))); height=max(260,min(1000,int(height)))
        except Exception:
            return {'ok':False,'error':'Invalid floating-player size.'}
        self._config['floating_width']=width; self._config['floating_height']=height; self._save_config()
        if self._floating_video and self.window: self.window.resize(width,height)
        return {'ok':True,'width':width,'height':height}

    def set_sound_preset(self, preset: str) -> dict:
        preset=str(preset or 'flat').lower()
        if preset not in {'flat','bass','voice','night'}: return {'ok':False,'error':'Unknown sound preset.'}
        self._config['sound_preset']=preset; self._save_config()
        if self.audio is not None and hasattr(self.audio,'set_sound_preset'):
            return self.audio.set_sound_preset(preset)
        return {'ok':True,'preset':preset,'limited':True}


    def _ani_cli_binary(self) -> str:
        configured = str(self._config.get('ani_cli_path', '') or '').strip()
        if configured:
            p = Path(configured).expanduser()
            if p.exists() and p.is_file():
                return str(p)
        return shutil.which('ani-cli') or ''

    def _terminal_command(self, executable: str, args: list[str]) -> list[str] | None:
        """Return a terminal launch command without passing user text through shell parsing."""
        terminal = (
            shutil.which('xfce4-terminal') or shutil.which('x-terminal-emulator') or
            shutil.which('gnome-terminal') or shutil.which('konsole') or
            shutil.which('mate-terminal')
        )
        if not terminal:
            return None
        name = Path(terminal).name
        command = [executable, *args]
        if name in {'gnome-terminal', 'mate-terminal'}:
            return [terminal, '--', *command]
        if name == 'xfce4-terminal':
            quoted = ' '.join(shlex.quote(x) for x in command)
            return [terminal, '--disable-server', '--command', quoted]
        if name == 'konsole':
            return [terminal, '-e', *command]
        return [terminal, '-e', *command]

    def plugin_status(self) -> dict:
        ani = self._ani_cli_binary()
        version = ''
        if ani:
            try:
                proc = subprocess.run([ani, '-V'], capture_output=True, text=True, timeout=8)
                version = (proc.stdout or proc.stderr or '').strip().splitlines()[0][:120]
            except Exception:
                version = ''
        custom = []
        for item in list(self._config.get('custom_plugins', []) or []):
            if not isinstance(item, dict):
                continue
            path = str(item.get('path', '') or '')
            custom.append({
                'name': str(item.get('name') or Path(path).name or 'Plugin')[:50],
                'path': path,
                'available': bool(path and Path(path).expanduser().exists()),
            })
        return {
            'ok': True,
            'ani_cli': {'available': bool(ani), 'path': ani, 'version': version},
            'custom_plugins': custom,
        }

    def add_local_plugin(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            paths = self.window.create_file_dialog(
                None, allow_multiple=False,
                file_types=('Executables (*)', 'All Files (*)'),
                title='Add local plugin executable'
            )
        except Exception as exc:
            return {'ok': False, 'error': f'Plugin picker failed: {exc}'}
        if not paths:
            return {'ok': True, 'cancelled': True}
        path = Path(str(paths[0])).expanduser().resolve()
        if not path.exists() or not path.is_file():
            return {'ok': False, 'error': 'Plugin executable was not found.'}
        if not os.access(path, os.X_OK):
            return {'ok': False, 'error': 'Selected file is not executable.'}
        if path.name == 'ani-cli':
            self._config['ani_cli_path'] = str(path)
        else:
            plugins = list(self._config.get('custom_plugins', []) or [])
            if not any(str(x.get('path', '')) == str(path) for x in plugins if isinstance(x, dict)):
                plugins.append({'name': path.stem[:50], 'path': str(path)})
            self._config['custom_plugins'] = plugins[:30]
        self._save_config()
        return self.plugin_status()

    def remove_local_plugin(self, path: str) -> dict:
        path = str(path or '')
        if path and path == str(self._config.get('ani_cli_path', '') or ''):
            self._config['ani_cli_path'] = ''
        plugins = [
            x for x in list(self._config.get('custom_plugins', []) or [])
            if isinstance(x, dict) and str(x.get('path', '')) != path
        ]
        self._config['custom_plugins'] = plugins
        self._save_config()
        return self.plugin_status()

    def launch_local_plugin(self, path: str) -> dict:
        p = Path(str(path or '')).expanduser()
        if not p.exists() or not p.is_file() or not os.access(p, os.X_OK):
            return {'ok': False, 'error': 'Plugin executable is unavailable.'}
        if p.name == 'ani-cli':
            return {'ok': False, 'error': 'Use the Anime tab. ani-cli now runs inside KLIGHTTEN MEDIA.'}
        cmd = self._terminal_command(str(p), [])
        if not cmd:
            return {'ok': False, 'error': 'No supported terminal emulator was found.'}
        try:
            subprocess.Popen(cmd, start_new_session=True)
            return {'ok': True, 'terminal': Path(cmd[0]).name}
        except Exception as exc:
            return {'ok': False, 'error': f'Could not launch plugin: {exc}'}

    def ani_cli_search(self, query: str, quality: str = '720') -> dict:
        # Compatibility alias: 2.3 runs ani-cli in KLIGHTTEN's in-app PTY.
        return self.ani_cli_start(query, quality)

    def ani_cli_update(self) -> dict:
        binary = self._ani_cli_binary()
        if not binary:
            return {'ok': False, 'error': 'ani-cli is not installed or added as a local plugin.'}
        try:
            proc = subprocess.run([binary, '-U'], capture_output=True, text=True, timeout=60)
            output = ((proc.stdout or '') + ('\n' + proc.stderr if proc.stderr else '')).strip()
            return {'ok': proc.returncode == 0, 'output': output[-5000:], 'returncode': proc.returncode}
        except subprocess.TimeoutExpired:
            return {'ok': False, 'error': 'ani-cli update timed out.'}
        except Exception as exc:
            return {'ok': False, 'error': f'ani-cli update failed: {exc}'}

    def youtube_http_status(self) -> dict:
        runtime = dict(getattr(self, 'runtime_info', {}) or {})
        provider = getattr(self, 'runtime_diagnostics_provider', None)
        extra = {}
        if callable(provider):
            try:
                extra = dict(provider() or {})
            except Exception:
                extra = {}
        last = str(extra.get('last_youtube_request', '') or '')
        host = ''
        try:
            host = urlparse(last).hostname or ''
        except Exception:
            host = ''
        return {
            'ok': True,
            'page_origin': runtime.get('page_origin', ''),
            'youtube_host': host or 'www.youtube.com',
            'request_count': int(extra.get('youtube_intercepted_requests', 0) or 0),
        }



    # ---------- Native remote-video player ----------
    # Remote streams from ani-cli may not be decodable by Qt WebEngine's
    # HTML5 video stack. The Qt shell therefore renders them with embedded MPV.

    def media_video_load(self, url: str, referrer: str = '', args=None,
                         autoplay: bool = True, volume: float = 70) -> dict:
        if not self.window or not hasattr(self.window, 'load_remote_video'):
            return {'ok': False, 'error': 'Native video surface is unavailable.'}
        return self.window.load_remote_video(
            str(url or ''), str(referrer or ''),
            list(args or []) if isinstance(args, (list, tuple)) else [],
            bool(autoplay), float(volume or 70)
        )

    def media_video_control(self, action: str, value=0) -> dict:
        if not self.window or not hasattr(self.window, 'control_remote_video'):
            return {'ok': False, 'error': 'Native video surface is unavailable.'}
        return self.window.control_remote_video(str(action or ''), value)

    def media_video_status(self) -> dict:
        if not self.window or not hasattr(self.window, 'remote_video_status'):
            return {'ok': False, 'error': 'Native video surface is unavailable.'}
        return self.window.remote_video_status()

    def media_video_geometry(self, x: int, y: int, width: int, height: int,
                             visible: bool = True) -> dict:
        if not self.window or not hasattr(self.window, 'set_remote_video_geometry'):
            return {'ok': False, 'error': 'Native video surface is unavailable.'}
        return self.window.set_remote_video_geometry(
            int(x), int(y), int(width), int(height), bool(visible)
        )

    def media_video_stop(self) -> dict:
        if not self.window or not hasattr(self.window, 'stop_remote_video'):
            return {'ok': True}
        return self.window.stop_remote_video()

    # ---------- Generic Media APIs ----------
    def media_api_providers(self) -> dict:
        providers = [{'id':'youtube','name':'YouTube','type':'youtube','configured':bool(self._config.get('youtube_api_key',''))}]
        seen={'youtube'}
        for raw in list(self._config.get('media_api_providers',[]) or []):
            if not isinstance(raw,dict):
                continue
            pid=str(raw.get('id','') or '').strip()
            if not pid or pid in seen:
                if pid=='youtube':
                    providers[0]['configured']=bool(raw.get('api_key') or self._config.get('youtube_api_key',''))
                continue
            seen.add(pid)
            providers.append({
                'id':pid,
                'name':str(raw.get('name') or pid)[:50],
                'type':'custom',
                'configured':bool(raw.get('search_url_template')),
                'search_url_template':str(raw.get('search_url_template','')),
                'results_path':str(raw.get('results_path','items')),
                'title_field':str(raw.get('title_field','title')),
                'url_field':str(raw.get('url_field','url')),
                'thumbnail_field':str(raw.get('thumbnail_field','thumbnail')),
                'artist_field':str(raw.get('artist_field','artist')),
                'auth_mode':str(raw.get('auth_mode','template')),
                'has_api_key':bool(raw.get('api_key')),
            })
        return {'ok':True,'providers':providers}

    def save_media_api_provider(self, provider_id: str, name: str, search_url_template: str,
                                api_key: str = '', results_path: str = 'items',
                                title_field: str = 'title', url_field: str = 'url',
                                thumbnail_field: str = 'thumbnail', artist_field: str = 'artist',
                                auth_mode: str = 'template') -> dict:
        provider_id=re.sub(r'[^a-z0-9_-]+','-',str(provider_id or name or '').strip().lower()).strip('-')[:40]
        if not provider_id or provider_id=='youtube':
            return {'ok':False,'error':'Choose a custom provider ID other than youtube.'}
        name=re.sub(r'\s+',' ',str(name or provider_id).strip())[:50]
        template=str(search_url_template or '').strip()
        try:
            u=urlparse(template.replace('{query}','test').replace('{key}','test'))
            if u.scheme!='https' or not u.netloc:
                raise ValueError()
        except Exception:
            return {'ok':False,'error':'Search URL must be an HTTPS URL template.'}
        if '{query}' not in template:
            return {'ok':False,'error':'Search URL template must contain {query}.'}
        auth_mode=str(auth_mode or 'template').lower()
        if auth_mode not in {'template','bearer','none'}:
            auth_mode='template'
        item={
            'id':provider_id,'name':name,'type':'custom','search_url_template':template,
            'api_key':str(api_key or '').strip(),'results_path':str(results_path or 'items').strip(),
            'title_field':str(title_field or 'title').strip(),'url_field':str(url_field or 'url').strip(),
            'thumbnail_field':str(thumbnail_field or 'thumbnail').strip(),'artist_field':str(artist_field or 'artist').strip(),
            'auth_mode':auth_mode,
        }
        providers=[x for x in list(self._config.get('media_api_providers',[]) or [])
                   if not (isinstance(x,dict) and x.get('id')==provider_id)]
        providers.append(item)
        self._config['media_api_providers']=providers[:20]
        self._save_config()
        return self.media_api_providers()

    def remove_media_api_provider(self, provider_id: str) -> dict:
        provider_id=str(provider_id or '')
        if provider_id=='youtube':
            return {'ok':False,'error':'YouTube is a built-in media provider.'}
        self._config['media_api_providers']=[
            x for x in list(self._config.get('media_api_providers',[]) or [])
            if not (isinstance(x,dict) and x.get('id')==provider_id)
        ]
        self._save_config()
        return self.media_api_providers()

    @staticmethod
    def _json_get(obj, path: str, default=''):
        if not path:
            return obj
        cur=obj
        for part in str(path).split('.'):
            if part=='':
                continue
            if isinstance(cur,dict):
                cur=cur.get(part, default)
            elif isinstance(cur,list) and part.isdigit():
                i=int(part); cur=cur[i] if 0<=i<len(cur) else default
            else:
                return default
        return cur

    def search_media(self, provider_id: str, query: str, max_results: int = 12) -> dict:
        provider_id=str(provider_id or 'youtube')
        query=str(query or '').strip()
        if provider_id=='youtube':
            return self.search_youtube(query,max_results)
        provider=next((x for x in list(self._config.get('media_api_providers',[]) or [])
                       if isinstance(x,dict) and x.get('id')==provider_id),None)
        if not provider:
            return {'ok':False,'error':'Media API provider not found.'}
        if not query:
            return {'ok':False,'error':'Enter a search query.'}
        template=str(provider.get('search_url_template',''))
        key=str(provider.get('api_key',''))
        url=template.replace('{query}', urlencode({'q':query})[2:]).replace('{key}', urlencode({'k':key})[2:])
        headers={'User-Agent':f'{APP_NAME}/{APP_VERSION}','Accept':'application/json'}
        if provider.get('auth_mode')=='bearer' and key:
            headers['Authorization']=f'Bearer {key}'
        try:
            with urlopen(Request(url,headers=headers),timeout=15) as response:
                payload=json.loads(response.read().decode('utf-8'))
        except Exception as exc:
            return {'ok':False,'error':f"Media API request failed: {exc}"}
        raw=self._json_get(payload,provider.get('results_path','items'),[])
        if isinstance(raw,dict):
            raw=list(raw.values())
        if not isinstance(raw,list):
            return {'ok':False,'error':'Media API result path did not resolve to a list.'}
        results=[]
        for item in raw[:max(1,min(int(max_results or 12),30))]:
            if not isinstance(item,dict): continue
            media_url=str(self._json_get(item,provider.get('url_field','url'),'') or '').strip()
            if not media_url: continue
            results.append({
                'id':f"media:{provider_id}:{len(results)}",
                'kind':'media_url','provider_id':provider_id,'provider_name':provider.get('name',provider_id),
                'title':str(self._json_get(item,provider.get('title_field','title'),'Untitled') or 'Untitled'),
                'artist':str(self._json_get(item,provider.get('artist_field','artist'),provider.get('name',provider_id)) or provider.get('name',provider_id)),
                'thumbnail':str(self._json_get(item,provider.get('thumbnail_field','thumbnail'),'') or ''),
                'artwork':str(self._json_get(item,provider.get('thumbnail_field','thumbnail'),'') or ''),
                'url':media_url,'source':provider.get('name',provider_id),
            })
        return {'ok':True,'results':results,'provider':provider.get('name',provider_id)}

    # ---------- In-app ani-cli PTY ----------
    def _ani_shim_path(self) -> Path:
        path = CONFIG_DIR / 'klightten-mpv-player'
        lines = [
            '#!/usr/bin/env python3',
            'import json, os, sys, time',
            'args=sys.argv[1:]',
            'capture=os.environ.get("KLIGHTTEN_ANI_CAPTURE","")',
            'done=os.environ.get("KLIGHTTEN_ANI_DONE","")',
            'url=next((x for x in args if x.startswith("http://") or x.startswith("https://")),"")',
            'title=""',
            'referrer=""',
            'for x in args:',
            '    if x.startswith("--force-media-title="): title=x.split("=",1)[1]',
            '    elif x.startswith("--meta-title="): title=x.split("=",1)[1]',
            '    elif x.startswith("--referrer="): referrer=x.split("=",1)[1]',
            '    elif x.startswith("--http-referrer="): referrer=x.split("=",1)[1]',
            'if capture:',
            '    try:',
            '        with open(capture,"w",encoding="utf-8") as f: json.dump({"url":url,"title":title,"referrer":referrer,"args":args},f)',
            '    except Exception: pass',
            'deadline=time.time()+8*3600',
            'while done and not os.path.exists(done) and time.time()<deadline: time.sleep(.25)',
        ]
        content = '\n'.join(lines) + '\n'
        try:
            if not path.exists() or path.read_text(encoding='utf-8', errors='ignore') != content:
                path.write_text(content, encoding='utf-8')
                os.chmod(path, 0o755)
        except Exception:
            pass
        return path

    def _strip_ansi(self, text: str) -> str:
        return re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', text)

    def _ani_terminal_reset(self, cols: int = 104, rows: int = 30) -> None:
        self._ani_raw_buffer = ''
        if PYTE_AVAILABLE:
            try:
                self._ani_screen = pyte.Screen(cols, rows)
                self._ani_stream = pyte.Stream(self._ani_screen)
                return
            except Exception:
                pass
        self._ani_screen = None
        self._ani_stream = None

    def _ani_terminal_render(self) -> str:
        if self._ani_screen is not None:
            try:
                lines = [str(line).rstrip() for line in self._ani_screen.display]
                # Draw a simple block cursor so the embedded terminal feels
                # like a normal terminal even though the screen is rendered
                # into HTML text.
                try:
                    cy = max(0, min(len(lines) - 1, int(self._ani_screen.cursor.y)))
                    cx = max(0, int(self._ani_screen.cursor.x))
                    line = lines[cy]
                    if len(line) < cx:
                        line += ' ' * (cx - len(line))
                    if cx < len(line):
                        line = line[:cx] + '█' + line[cx + 1:]
                    else:
                        line = line + '█'
                    lines[cy] = line
                except Exception:
                    pass
                while lines and not lines[-1]:
                    lines.pop()
                return '\n'.join(lines)
            except Exception:
                pass
        return self._strip_ansi(self._ani_raw_buffer)[-30000:]

    def ani_cli_resize(self, cols: int = 104, rows: int = 30) -> dict:
        try:
            cols=max(40,min(220,int(cols))); rows=max(12,min(80,int(rows)))
        except Exception:
            cols,rows=104,30
        fd=self._ani_master_fd
        if fd is not None:
            try:
                fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))
            except Exception:
                pass
        if self._ani_screen is not None:
            try:
                self._ani_screen.resize(lines=rows, columns=cols)
            except Exception:
                pass
        return {'ok':True,'cols':cols,'rows':rows}

    def ani_cli_start(self, query: str, quality: str = '720') -> dict:
        binary = self._ani_cli_binary()
        if not binary:
            return {'ok': False, 'error': 'ani-cli is not installed or configured in Plugins.'}
        query = re.sub(r'\s+', ' ', str(query or '').strip())[:180]
        if not query:
            return {'ok': False, 'error': 'Enter an anime title.'}
        self.ani_cli_stop()
        quality = str(quality or '720')
        qarg = 'best' if quality == 'best' else (quality if quality.endswith('p') else quality + 'p')
        session_id = uuid.uuid4().hex[:12]
        ANI_CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
        capture = ANI_CAPTURE_DIR / f'{session_id}.json'
        done = ANI_CAPTURE_DIR / f'{session_id}.done'
        for item in (capture, done):
            try:
                item.unlink(missing_ok=True)
            except Exception:
                pass
        master, slave = pty.openpty()
        cols, rows = 104, 30
        try:
            fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', rows, cols, 0, 0))
        except Exception:
            pass
        env = os.environ.copy()
        env.update({
            'TERM': 'xterm-256color', 'COLORTERM': 'truecolor',
            'COLUMNS': str(cols), 'LINES': str(rows),
            'ANI_CLI_PLAYER': str(self._ani_shim_path()),
            'ANI_CLI_NO_DETACH': '1',
            'KLIGHTTEN_ANI_CAPTURE': str(capture),
            'KLIGHTTEN_ANI_DONE': str(done),
        })
        def _pty_child_setup():
            os.setsid()
            try:
                fcntl.ioctl(slave, termios.TIOCSCTTY, 0)
            except Exception:
                pass
        try:
            proc = subprocess.Popen(
                [binary, '-q', qarg, query],
                stdin=slave, stdout=slave, stderr=slave,
                env=env, close_fds=True, preexec_fn=_pty_child_setup,
            )
            os.close(slave)
            os.set_blocking(master, False)
            self._ani_terminal_reset(cols, rows)
        except Exception as exc:
            try:
                os.close(master)
                os.close(slave)
            except Exception:
                pass
            return {'ok': False, 'error': f'Could not start ani-cli: {exc}'}
        self._ani_process = proc
        self._ani_master_fd = master
        self._ani_last_capture = ''
        # _ani_terminal_reset() above already created the ANSI screen/stream.
        # Do not clear them here; doing so disables terminal emulation.
        self._ani_session = {
            'id': session_id, 'query': query, 'quality': quality,
            'capture': str(capture), 'done': str(done), 'started_at': time.time(),
        }
        return {'ok': True, 'session_id': session_id, 'pid': proc.pid, 'query': query, 'quality': quality}

    def ani_cli_send(self, text: str) -> dict:
        if self._ani_master_fd is None:
            return {'ok': False, 'error': 'ani-cli session is not running.'}
        try:
            os.write(self._ani_master_fd, str(text or '').encode('utf-8'))
            return {'ok': True}
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def ani_cli_key(self, key: str) -> dict:
        key = str(key or '').lower()
        mapping = {
            'enter': '\r',
            'up': '\x1b[A', 'down': '\x1b[B',
            'right': '\x1b[C', 'left': '\x1b[D',
            'escape': '\x1b',
            'space': ' ',
            'tab': '\t',
            'backspace': '\x7f',
            'delete': '\x1b[3~',
            'insert': '\x1b[2~',
            'home': '\x1b[H',
            'end': '\x1b[F',
            'pageup': '\x1b[5~',
            'pagedown': '\x1b[6~',
            'f1': '\x1bOP', 'f2': '\x1bOQ', 'f3': '\x1bOR', 'f4': '\x1bOS',
            'f5': '\x1b[15~', 'f6': '\x1b[17~', 'f7': '\x1b[18~',
            'f8': '\x1b[19~', 'f9': '\x1b[20~', 'f10': '\x1b[21~',
            'f11': '\x1b[23~', 'f12': '\x1b[24~',
        }
        if key.startswith('ctrl-') and len(key) == 6:
            letter = key[-1]
            if 'a' <= letter <= 'z':
                return self.ani_cli_send(chr(ord(letter) - ord('a') + 1))
        return self.ani_cli_send(mapping.get(key, key))

    def _append_anime_history(self, media: dict) -> None:
        try:
            history = []
            if ANIME_HISTORY_FILE.exists():
                raw = json.loads(ANIME_HISTORY_FILE.read_text(encoding='utf-8'))
                if isinstance(raw, list):
                    history = raw
            session = self._ani_session or {}
            title = str(media.get('title') or session.get('query') or 'Anime')
            match = re.search(r'episode\s*([0-9]+(?:\.[0-9]+)?)', title, re.I)
            entry = {
                'title': re.sub(r'\s*episode\s*[0-9.]+\s*$', '', title, flags=re.I).strip() or session.get('query', 'Anime'),
                'episode': match.group(1) if match else '',
                'display_title': title,
                'query': session.get('query', ''),
                'quality': session.get('quality', ''),
                'backend': 'auto',
                'watched_at': datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds'),
                'timestamp': time.time(),
            }
            if not history or history[0].get('display_title') != entry['display_title'] or time.time() - float(history[0].get('timestamp', 0)) > 120:
                history.insert(0, entry)
            ANIME_HISTORY_FILE.write_text(json.dumps(history[:200], indent=2), encoding='utf-8')
        except Exception:
            pass

    def ani_cli_read(self) -> dict:
        output = ''
        if self._ani_master_fd is not None:
            for _ in range(12):
                try:
                    chunk = os.read(self._ani_master_fd, 65536)
                    if not chunk:
                        break
                    output += chunk.decode('utf-8', errors='replace')
                except BlockingIOError:
                    break
                except OSError as exc:
                    if exc.errno in (errno.EIO, errno.EBADF):
                        break
                    break
        if output:
            self._ani_raw_buffer = (self._ani_raw_buffer + output)[-120000:]
            if self._ani_stream is not None:
                try:
                    self._ani_stream.feed(output)
                except Exception:
                    pass
        screen_text = self._ani_terminal_render()
        media = None
        session = self._ani_session or {}
        cap = Path(session.get('capture', '')) if session.get('capture') else None
        if cap and cap.exists():
            try:
                raw = cap.read_text(encoding='utf-8')
                if raw and raw != self._ani_last_capture:
                    self._ani_last_capture = raw
                    media = json.loads(raw)
                    media['kind'] = 'anime_media'
                    media['source'] = 'ani-cli'
                    media['query'] = session.get('query', '')
                    if callable(self.runtime_media_referrer_setter) and media.get('url'):
                        try:
                            self.runtime_media_referrer_setter(media.get('url', ''), media.get('referrer', ''))
                        except Exception:
                            pass
                    self._append_anime_history(media)
            except Exception:
                media = None
        running = bool(self._ani_process is not None and self._ani_process.poll() is None)
        code = None if running or self._ani_process is None else self._ani_process.returncode
        return {'ok': True, 'running': running, 'exit_code': code, 'output': self._strip_ansi(output), 'screen': screen_text, 'terminal_emulator': 'pyte' if PYTE_AVAILABLE else 'fallback', 'media': media}

    def ani_cli_player_done(self) -> dict:
        session = self._ani_session or {}
        done = session.get('done')
        if done:
            try:
                Path(done).touch()
            except Exception:
                pass
        return {'ok': True}

    def ani_cli_stop(self) -> dict:
        session = self._ani_session or {}
        done = session.get('done')
        if done:
            try:
                Path(done).touch()
            except Exception:
                pass
        proc = self._ani_process
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=1.5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
        if self._ani_master_fd is not None:
            try:
                os.close(self._ani_master_fd)
            except Exception:
                pass
        self._ani_process = None
        self._ani_master_fd = None
        self._ani_session = None
        self._ani_screen = None; self._ani_stream = None; self._ani_raw_buffer = ''
        return {'ok': True}

    def ani_cli_history(self) -> dict:
        detailed = []
        try:
            if ANIME_HISTORY_FILE.exists():
                raw = json.loads(ANIME_HISTORY_FILE.read_text(encoding='utf-8'))
                if isinstance(raw, list):
                    detailed = raw[:100]
        except Exception:
            pass
        resume = []
        try:
            state_home = Path(os.environ.get('XDG_STATE_HOME') or (Path.home() / '.local/state'))
            hist = state_home / 'ani-cli' / 'ani-hsts'
            if hist.exists():
                for line in hist.read_text(encoding='utf-8', errors='replace').splitlines()[-100:][::-1]:
                    parts = line.split('\t', 1)
                    label = parts[1] if len(parts) > 1 else parts[0]
                    match = re.search(r'(.+?)\s*-\s*episode\s*([0-9.]+)', label, re.I)
                    resume.append({
                        'raw': label,
                        'title': match.group(1).strip() if match else label,
                        'episode': match.group(2) if match else '',
                    })
        except Exception:
            pass
        return {'ok': True, 'history': detailed, 'resume': resume}

    def start_resize(self, edge: str = 'bottom-right') -> dict:
        if self.window and hasattr(self.window, 'start_resize'):
            try:
                return {'ok': True, 'started': bool(self.window.start_resize(str(edge)))}
            except Exception as exc:
                return {'ok': False, 'error': f'Could not resize window: {exc}'}
        return {'ok': False, 'error': 'Native window resizing is unavailable.'}



    def set_media_fullscreen(self, enabled: bool) -> dict:
        if not self.window or not hasattr(self.window, 'set_media_fullscreen'):
            return {'ok': False, 'error': 'Native fullscreen is unavailable.'}
        return self.window.set_media_fullscreen(bool(enabled))

    def media_fullscreen_status(self) -> dict:
        if not self.window or not hasattr(self.window, 'media_fullscreen_status'):
            return {'ok': True, 'fullscreen': False}
        return self.window.media_fullscreen_status()

    def bind_window(self, window) -> None:
        self.window = window

    def _load_config(self) -> dict:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        default = {
            'youtube_api_key': '',
            'theme': 'neon-arcade',
            'volume': 70,
            'low_end_mode': True,
            'profile_name': 'KLIGHTTEN User',
            'profile_picture': '',
            'sound_preset': 'flat',
            'floating_width': 620,
            'floating_height': 460,
            'ani_cli_path': '',
            'custom_plugins': [],
            'media_api_providers': [],
            'youtube_accounts': [],
            'active_youtube_account': '',
        }
        if CONFIG_FILE.exists():
            try:
                data = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
                if isinstance(data, dict):
                    default.update(data)
                    # 2.3 migrates the old YouTube-only API key into the generic Media API layer.
                    providers = list(default.get('media_api_providers', []) or [])
                    if default.get('youtube_api_key') and not any(isinstance(x,dict) and x.get('id')=='youtube' for x in providers):
                        providers.insert(0, {'id':'youtube','name':'YouTube','type':'youtube','api_key':default.get('youtube_api_key','')})
                    default['media_api_providers'] = providers
            except (OSError, json.JSONDecodeError):
                pass
        return default

    def _save_config(self) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(self._config, indent=2), encoding='utf-8')
        try:
            os.chmod(CONFIG_FILE, 0o600)
        except OSError:
            pass

    def get_settings(self) -> dict:
        return {
            'ok': True,
            'theme': self._config.get('theme', 'neon-arcade'),
            'has_api_key': bool(self._config.get('youtube_api_key', '')),
            'volume': int(self._config.get('volume', 70)),
            'low_end_mode': bool(self._config.get('low_end_mode', True)),
            'app_name': APP_NAME,
            'version': APP_VERSION,
            'audio_backend': self.audio_backend,
            'player_backend': 'auto',
            'sound_preset': self._config.get('sound_preset','flat'),
            'profile_name': self._config.get('profile_name','KLIGHTTEN User'),
            'profile_picture_data': self._profile_picture_data(),
            'floating_width': int(self._config.get('floating_width',620)),
            'floating_height': int(self._config.get('floating_height',460)),
            'oauth_available': GOOGLE_AUTH_AVAILABLE,
            'oauth_client_configured': OAUTH_CLIENT_FILE.exists(),
            'youtube_signed_in': bool(self._get_google_credentials()),
            'ani_cli_available': bool(self._ani_cli_binary()),
            'custom_plugins': list(self._config.get('custom_plugins', []) or []),
            'media_api_providers': self.media_api_providers().get('providers', []),
            'youtube_accounts': self.youtube_accounts_status(False).get('accounts', []),
            'active_youtube_account': self._config.get('active_youtube_account',''),
        }

    def save_theme(self, theme: str) -> dict:
        allowed = {'neon-arcade', 'classic-green', 'black-white', 'redhat'}
        if theme not in allowed:
            return {'ok': False, 'error': 'Unknown theme.'}
        self._config['theme'] = theme
        self._save_config()
        return {'ok': True}

    def save_low_end_mode(self, enabled: bool) -> dict:
        self._config['low_end_mode'] = bool(enabled)
        self._save_config()
        return {'ok': True, 'low_end_mode': bool(enabled)}

    def save_api_key(self, api_key: str) -> dict:
        api_key = (api_key or '').strip()
        if api_key and len(api_key) < 20:
            return {'ok': False, 'error': 'That API key looks too short.'}
        self._config['youtube_api_key'] = api_key
        providers=list(self._config.get('media_api_providers',[]) or [])
        found=False
        for item in providers:
            if isinstance(item,dict) and item.get('id')=='youtube':
                item['api_key']=api_key; item['name']='YouTube'; item['type']='youtube'; found=True
        if not found:
            providers.insert(0, {'id':'youtube','name':'YouTube','type':'youtube','api_key':api_key})
        self._config['media_api_providers']=providers
        self._save_config()
        return {'ok': True, 'has_api_key': bool(api_key)}

    def clear_api_key(self) -> dict:
        self._config['youtube_api_key'] = ''
        for item in list(self._config.get('media_api_providers',[]) or []):
            if isinstance(item,dict) and item.get('id')=='youtube':
                item['api_key']=''
        self._save_config()
        return {'ok': True}

    def get_app_state(self) -> dict:
        default = {
            'queue': [], 'current_index': -1, 'favorites': [], 'history': [],
            'library': [], 'library_folder': '', 'videos': [], 'video_folder': '', 'repeat_mode': 'off', 'shuffle': False,
        }
        if STATE_FILE.exists():
            try:
                data = json.loads(STATE_FILE.read_text(encoding='utf-8'))
                if isinstance(data, dict):
                    default.update(data)
                    # 2.3 migrates the old YouTube-only API key into the generic Media API layer.
                    providers = list(default.get('media_api_providers', []) or [])
                    if default.get('youtube_api_key') and not any(isinstance(x,dict) and x.get('id')=='youtube' for x in providers):
                        providers.insert(0, {'id':'youtube','name':'YouTube','type':'youtube','api_key':default.get('youtube_api_key','')})
                    default['media_api_providers'] = providers
            except (OSError, json.JSONDecodeError):
                pass
        # Keep startup lightweight: validate saved local paths without reparsing every file.
        # Full metadata/cover art is refreshed when a track is played or a folder is rescanned.
        for key in ('queue', 'favorites', 'history', 'library', 'videos'):
            refreshed = []
            limit = MAX_STATE_QUEUE if key == 'queue' else MAX_LIBRARY_TRACKS
            for t in default.get(key, [])[:limit]:
                if isinstance(t, dict) and t.get('kind') in {'local', 'local_video'} and t.get('path'):
                    p = Path(str(t['path'])).expanduser()
                    if p.exists() and p.is_file():
                        refreshed.append(_compact_track(t))
                elif isinstance(t, dict) and t.get('kind') == 'youtube':
                    refreshed.append(_compact_track(t))
            default[key] = refreshed
        return {'ok': True, 'state': default}

    def save_app_state(self, state: dict) -> dict:
        if not isinstance(state, dict):
            return {'ok': False, 'error': 'Invalid app state.'}
        safe = {
            'queue': [_compact_track(t) for t in state.get('queue', []) if isinstance(t, dict)][:MAX_STATE_QUEUE],
            'current_index': int(state.get('current_index', -1)) if str(state.get('current_index', -1)).lstrip('-').isdigit() else -1,
            'favorites': [_compact_track(t) for t in state.get('favorites', []) if isinstance(t, dict)][:MAX_LIBRARY_TRACKS],
            'history': [_compact_track(t) for t in state.get('history', []) if isinstance(t, dict)][:MAX_HISTORY],
            'library': [_compact_track(t) for t in state.get('library', []) if isinstance(t, dict)][:MAX_LIBRARY_TRACKS],
            'library_folder': str(state.get('library_folder', ''))[:4096],
            'videos': [_compact_track(t) for t in state.get('videos', []) if isinstance(t, dict)][:MAX_VIDEO_FILES],
            'video_folder': str(state.get('video_folder', ''))[:4096],
            'repeat_mode': state.get('repeat_mode', 'off') if state.get('repeat_mode') in {'off', 'all', 'one'} else 'off',
            'shuffle': bool(state.get('shuffle', False)),
        }
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(safe, indent=2), encoding='utf-8')
        try:
            os.chmod(STATE_FILE, 0o600)
        except OSError:
            pass
        return {'ok': True}

    def choose_audio_files(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            dialog_type = getattr(getattr(webview, 'FileDialog', None), 'LOAD', None)
            if dialog_type is None:
                dialog_type = getattr(webview, 'OPEN_DIALOG', None)
            paths = self.window.create_file_dialog(
                dialog_type,
                allow_multiple=True,
                file_types=(
                    'Audio Files (*.mp3;*.wav;*.ogg;*.oga;*.flac;*.m4a;*.aac;*.opus;*.wma)',
                    'All Files (*.*)',
                ),
            )
        except Exception as exc:
            return {'ok': False, 'error': f'File picker failed: {exc}'}
        if not paths:
            return {'ok': True, 'tracks': []}
        tracks = []
        for raw in paths:
            path = Path(str(raw)).expanduser().resolve()
            if path.exists() and path.is_file() and path.suffix.lower() in AUDIO_EXTENSIONS:
                tracks.append(read_audio_metadata(path))
        return {'ok': True, 'tracks': tracks}

    def choose_music_folder(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            dialog_type = getattr(getattr(webview, 'FileDialog', None), 'FOLDER', None)
            if dialog_type is None:
                dialog_type = getattr(webview, 'FOLDER_DIALOG', None)
            paths = self.window.create_file_dialog(dialog_type, allow_multiple=False)
        except Exception as exc:
            return {'ok': False, 'error': f'Folder picker failed: {exc}'}
        if not paths:
            return {'ok': True, 'folder': '', 'tracks': []}
        folder = Path(str(paths[0])).expanduser().resolve()
        if not folder.is_dir():
            return {'ok': False, 'error': 'Selected path is not a folder.'}
        return self.scan_music_folder(str(folder))

    def scan_music_folder(self, folder: str) -> dict:
        root = Path(folder).expanduser().resolve()
        if not root.exists() or not root.is_dir():
            return {'ok': False, 'error': 'Music folder was not found.'}
        tracks = []
        try:
            for current_root, dirs, files in os.walk(root):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for name in files:
                    p = Path(current_root) / name
                    if p.suffix.lower() in AUDIO_EXTENSIONS:
                        tracks.append(read_audio_metadata(p, include_art=False))
                        if len(tracks) >= MAX_LIBRARY_TRACKS:
                            break
                if len(tracks) >= MAX_LIBRARY_TRACKS:
                    break
        except OSError as exc:
            return {'ok': False, 'error': f'Could not scan folder: {exc}'}
        tracks.sort(key=lambda t: ((t.get('artist') or '').casefold(), (t.get('album') or '').casefold(), (t.get('title') or '').casefold()))
        return {'ok': True, 'folder': str(root), 'tracks': tracks, 'limit_reached': len(tracks) >= MAX_LIBRARY_TRACKS}


    def _video_item(self, path: Path) -> dict:
        path = path.expanduser().resolve()
        return {
            'id': f'video:{path}',
            'kind': 'local_video',
            'path': str(path),
            'filename': path.name,
            'title': path.stem,
            'artist': 'Local video',
            'album': path.parent.name,
            'duration': 0,
            'extension': path.suffix.lower().lstrip('.').upper(),
            'source': 'Local Video',
            'media_type': 'video',
            'artwork': '',
        }

    def choose_video_files(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            dialog_type = getattr(getattr(webview, 'FileDialog', None), 'LOAD', None)
            if dialog_type is None:
                dialog_type = getattr(webview, 'OPEN_DIALOG', None)
            paths = self.window.create_file_dialog(
                dialog_type,
                allow_multiple=True,
                file_types=(
                    'Video Files (*.mp4;*.mkv;*.webm;*.mov;*.avi;*.m4v;*.mpeg;*.mpg;*.ts;*.flv;*.wmv)',
                    'All Files (*.*)',
                ),
                title='Choose local videos',
            )
        except Exception as exc:
            return {'ok': False, 'error': f'Video file picker failed: {exc}'}

        if not paths:
            return {'ok': True, 'videos': []}

        videos = []
        for raw in paths:
            path = Path(str(raw)).expanduser().resolve()
            if path.exists() and path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS:
                videos.append(self._video_item(path))
        return {'ok': True, 'videos': videos}

    def choose_video_folder(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            dialog_type = getattr(getattr(webview, 'FileDialog', None), 'FOLDER', None)
            if dialog_type is None:
                dialog_type = getattr(webview, 'FOLDER_DIALOG', None)
            paths = self.window.create_file_dialog(
                dialog_type,
                allow_multiple=False,
                title='Choose video folder',
            )
        except Exception as exc:
            return {'ok': False, 'error': f'Video folder picker failed: {exc}'}

        if not paths:
            return {'ok': True, 'folder': '', 'videos': []}
        folder = Path(str(paths[0])).expanduser().resolve()
        if not folder.is_dir():
            return {'ok': False, 'error': 'Selected video path is not a folder.'}
        return self.scan_video_folder(str(folder))

    def scan_video_folder(self, folder: str) -> dict:
        root = Path(str(folder or '')).expanduser().resolve()
        if not root.exists() or not root.is_dir():
            return {'ok': False, 'error': 'Video folder was not found.'}

        videos = []
        try:
            for current_root, dirs, files in os.walk(root):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for name in files:
                    p = Path(current_root) / name
                    if p.suffix.lower() in VIDEO_EXTENSIONS:
                        videos.append(self._video_item(p))
                        if len(videos) >= MAX_VIDEO_FILES:
                            break
                if len(videos) >= MAX_VIDEO_FILES:
                    break
        except OSError as exc:
            return {'ok': False, 'error': f'Could not scan video folder: {exc}'}

        videos.sort(key=lambda v: (str(v.get('title') or '').casefold(), str(v.get('path') or '').casefold()))
        return {
            'ok': True,
            'folder': str(root),
            'videos': videos,
            'limit_reached': len(videos) >= MAX_VIDEO_FILES,
        }

    def converter_capabilities(self) -> dict:
        return {
            'ok': True,
            'ffmpeg': shutil.which('ffmpeg') or '',
            'ffprobe': shutil.which('ffprobe') or '',
            'default_output_folder': str(CONVERTER_DEFAULT_DIR),
            'formats': ['mp3', 'mp4'],
        }

    def choose_converter_input(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            dialog_type = getattr(getattr(webview, 'FileDialog', None), 'LOAD', None)
            if dialog_type is None:
                dialog_type = getattr(webview, 'OPEN_DIALOG', None)
            paths = self.window.create_file_dialog(
                dialog_type,
                allow_multiple=False,
                file_types=(
                    'Media Files (*.mp3;*.wav;*.ogg;*.oga;*.flac;*.m4a;*.aac;*.opus;*.wma;*.mp4;*.mkv;*.webm;*.mov;*.avi;*.m4v;*.mpeg;*.mpg;*.ts;*.flv)',
                    'Audio Files (*.mp3;*.wav;*.ogg;*.oga;*.flac;*.m4a;*.aac;*.opus;*.wma)',
                    'Video Files (*.mp4;*.mkv;*.webm;*.mov;*.avi;*.m4v;*.mpeg;*.mpg;*.ts;*.flv)',
                    'All Files (*.*)',
                ),
                title='Choose media to convert',
            )
        except Exception as exc:
            return {'ok': False, 'error': f'File picker failed: {exc}'}
        if not paths:
            return {'ok': True, 'cancelled': True}
        path = Path(str(paths[0])).expanduser().resolve()
        if not path.exists() or not path.is_file():
            return {'ok': False, 'error': 'Selected file does not exist.'}
        if path.suffix.lower() not in MEDIA_EXTENSIONS:
            return {'ok': False, 'error': 'That file type is not supported by the converter.'}
        try:
            size = path.stat().st_size
        except OSError:
            size = 0
        return {
            'ok': True,
            'path': str(path),
            'name': path.name,
            'extension': path.suffix.lower().lstrip('.').upper() or 'FILE',
            'size': int(size),
        }

    def choose_converter_output_folder(self) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        try:
            dialog_type = getattr(getattr(webview, 'FileDialog', None), 'FOLDER', None)
            if dialog_type is None:
                dialog_type = getattr(webview, 'FOLDER_DIALOG', None)
            paths = self.window.create_file_dialog(
                dialog_type,
                allow_multiple=False,
                title='Choose converter output folder',
            )
        except Exception as exc:
            return {'ok': False, 'error': f'Folder picker failed: {exc}'}
        if not paths:
            return {'ok': True, 'cancelled': True}
        folder = Path(str(paths[0])).expanduser().resolve()
        return {'ok': True, 'folder': str(folder)}

    def _probe_duration(self, path: Path) -> float:
        ffprobe = shutil.which('ffprobe')
        if not ffprobe:
            return 0.0
        try:
            result = subprocess.run(
                [ffprobe, '-v', 'error', '-show_entries', 'format=duration',
                 '-of', 'default=noprint_wrappers=1:nokey=1', str(path)],
                capture_output=True, text=True, timeout=12,
            )
            if result.returncode == 0:
                return max(0.0, float((result.stdout or '0').strip() or 0))
        except Exception:
            pass
        return 0.0

    @staticmethod
    def _unique_output_path(folder: Path, source: Path, output_format: str) -> Path:
        stem = source.stem.strip() or 'converted'
        candidate = folder / f'{stem}.{output_format}'
        if candidate.resolve() == source.resolve() or candidate.exists():
            candidate = folder / f'{stem}-converted.{output_format}'
        counter = 2
        while candidate.exists():
            candidate = folder / f'{stem}-converted-{counter}.{output_format}'
            counter += 1
        return candidate

    def _conversion_command(self, source: Path, output: Path, output_format: str, quality: str) -> list[str]:
        ffmpeg = shutil.which('ffmpeg')
        if not ffmpeg:
            raise RuntimeError('FFmpeg is not installed. Run ./setup.sh again.')
        base = [ffmpeg, '-hide_banner', '-y', '-i', str(source)]
        if output_format == 'mp3':
            bitrate = quality if quality in {'128', '192', '256', '320'} else '192'
            return base + [
                '-vn', '-c:a', 'libmp3lame', '-b:a', f'{bitrate}k',
                '-map_metadata', '0', '-id3v2_version', '3',
                '-progress', 'pipe:1', '-nostats', str(output),
            ]

        # H.264/AAC MP4. Defaults are intentionally CPU-conscious for older Linux systems.
        preset = quality if quality in {'fast480', 'balanced720', 'high'} else 'fast480'
        args = base + ['-map', '0:v:0?', '-map', '0:a:0?']
        if preset == 'fast480':
            args += [
                '-vf', "scale=w='min(854,iw)':h='min(480,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2",
                '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '27',
                '-c:a', 'aac', '-b:a', '128k',
            ]
        elif preset == 'balanced720':
            args += [
                '-vf', "scale=w='min(1280,iw)':h='min(720,ih)':force_original_aspect_ratio=decrease:force_divisible_by=2",
                '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23',
                '-c:a', 'aac', '-b:a', '160k',
            ]
        else:
            args += [
                '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '19',
                '-c:a', 'aac', '-b:a', '192k',
            ]
        args += ['-pix_fmt', 'yuv420p', '-movflags', '+faststart', '-map_metadata', '0',
                 '-progress', 'pipe:1', '-nostats', str(output)]
        return args

    def start_conversion(self, input_path: str, output_format: str, quality: str, output_folder: str = '') -> dict:
        source = Path(str(input_path or '')).expanduser().resolve()
        output_format = str(output_format or '').lower().strip()
        quality = str(quality or '').strip()
        if not source.exists() or not source.is_file():
            return {'ok': False, 'error': 'Choose a valid local media file first.'}
        if source.suffix.lower() not in MEDIA_EXTENSIONS:
            return {'ok': False, 'error': 'Unsupported input file type.'}
        if output_format not in {'mp3', 'mp4'}:
            return {'ok': False, 'error': 'Output format must be MP3 or MP4.'}
        if not shutil.which('ffmpeg'):
            return {'ok': False, 'error': 'FFmpeg is missing. Run ./setup.sh again.'}
        folder = Path(output_folder).expanduser().resolve() if str(output_folder or '').strip() else CONVERTER_DEFAULT_DIR
        try:
            folder.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return {'ok': False, 'error': f'Could not create output folder: {exc}'}
        if not folder.is_dir():
            return {'ok': False, 'error': 'Output path is not a folder.'}

        output = self._unique_output_path(folder, source, output_format)
        job_id = f'conv-{int(time.time()*1000)}-{os.getpid()}-{len(self._conversion_jobs)+1}'
        job = {
            'id': job_id, 'state': 'queued', 'progress': 0.0,
            'status': 'Preparing conversion…', 'input': str(source),
            'input_name': source.name, 'output': str(output), 'output_name': output.name,
            'format': output_format, 'quality': quality, 'error': '',
            'started_at': time.time(), 'completed_at': 0.0,
        }
        with self._conversion_lock:
            self._conversion_jobs[job_id] = job
        thread = threading.Thread(
            target=self._run_conversion_job,
            args=(job_id, source, output, output_format, quality),
            name=f'klightten-converter-{job_id[-6:]}', daemon=True,
        )
        thread.start()
        return {'ok': True, 'job': dict(job)}

    def _run_conversion_job(self, job_id: str, source: Path, output: Path, output_format: str, quality: str) -> None:
        duration = self._probe_duration(source)
        try:
            cmd = self._conversion_command(source, output, output_format, quality)
        except Exception as exc:
            with self._conversion_lock:
                job = self._conversion_jobs.get(job_id, {})
                job.update(state='error', error=str(exc), status='Conversion could not start.', completed_at=time.time())
            return
        log_path = Path(tempfile.gettempdir()) / f'{job_id}.log'
        try:
            with open(log_path, 'w+', encoding='utf-8', errors='replace') as log:
                process = subprocess.Popen(
                    cmd, stdout=subprocess.PIPE, stderr=log, text=True,
                    bufsize=1, start_new_session=True,
                )
                with self._conversion_lock:
                    self._conversion_processes[job_id] = process
                    job = self._conversion_jobs[job_id]
                    job.update(state='running', status='Converting…', progress=1.0, pid=process.pid)
                if process.stdout is not None:
                    for raw in process.stdout:
                        line = raw.strip()
                        if '=' not in line:
                            continue
                        key, value = line.split('=', 1)
                        progress = None
                        if key in {'out_time_us', 'out_time_ms'} and duration > 0:
                            try:
                                progress = min(99.0, max(1.0, float(value) / (duration * 1_000_000.0) * 100.0))
                            except Exception:
                                progress = None
                        elif key == 'progress' and value == 'end':
                            progress = 100.0
                        if progress is not None:
                            with self._conversion_lock:
                                if job_id in self._conversion_jobs:
                                    self._conversion_jobs[job_id]['progress'] = round(progress, 1)
                                    self._conversion_jobs[job_id]['status'] = f'Converting… {progress:.0f}%'
                code = process.wait()
                with self._conversion_lock:
                    cancelled = bool(self._conversion_jobs.get(job_id, {}).get('cancel_requested'))
                if cancelled:
                    try:
                        output.unlink(missing_ok=True)
                    except Exception:
                        pass
                    with self._conversion_lock:
                        self._conversion_jobs[job_id].update(
                            state='cancelled', status='Conversion cancelled.', progress=0.0,
                            completed_at=time.time(),
                        )
                elif code == 0 and output.exists() and output.stat().st_size > 0:
                    with self._conversion_lock:
                        self._conversion_jobs[job_id].update(
                            state='done', status='Conversion complete.', progress=100.0,
                            completed_at=time.time(), size=int(output.stat().st_size),
                        )
                else:
                    log.seek(0)
                    detail = log.read()[-5000:].strip()
                    with self._conversion_lock:
                        self._conversion_jobs[job_id].update(
                            state='error', status='Conversion failed.',
                            error=detail or f'FFmpeg exited with code {code}.',
                            completed_at=time.time(),
                        )
        except Exception as exc:
            try:
                output.unlink(missing_ok=True)
            except Exception:
                pass
            with self._conversion_lock:
                if job_id in self._conversion_jobs:
                    self._conversion_jobs[job_id].update(
                        state='error', status='Conversion failed.', error=str(exc), completed_at=time.time(),
                    )
        finally:
            with self._conversion_lock:
                self._conversion_processes.pop(job_id, None)
            try:
                log_path.unlink(missing_ok=True)
            except Exception:
                pass

    def conversion_status(self, job_id: str) -> dict:
        with self._conversion_lock:
            job = self._conversion_jobs.get(str(job_id), None)
            if not job:
                return {'ok': False, 'error': 'Conversion job was not found.'}
            clean = {k: v for k, v in job.items() if k != 'cancel_requested'}
        return {'ok': True, 'job': clean}

    def cancel_conversion(self, job_id: str) -> dict:
        job_id = str(job_id)
        with self._conversion_lock:
            job = self._conversion_jobs.get(job_id)
            if not job:
                return {'ok': False, 'error': 'Conversion job was not found.'}
            if job.get('state') in {'done', 'error', 'cancelled'}:
                return {'ok': True, 'state': job.get('state')}
            job['cancel_requested'] = True
            job['status'] = 'Cancelling…'
            process = self._conversion_processes.get(job_id)
        if process is not None and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        return {'ok': True, 'state': 'cancelling'}

    def open_output_folder(self, output_path: str) -> dict:
        path = Path(str(output_path or '')).expanduser().resolve()
        folder = path if path.is_dir() else path.parent
        if not folder.exists() or not folder.is_dir():
            return {'ok': False, 'error': 'Output folder was not found.'}
        opener = shutil.which('xdg-open')
        if not opener:
            return {'ok': False, 'error': 'xdg-open is unavailable.'}
        try:
            subprocess.Popen([opener, str(folder)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return {'ok': True}
        except Exception as exc:
            return {'ok': False, 'error': f'Could not open folder: {exc}'}

    def _audio_unavailable(self) -> dict:
        return {'ok': False, 'error': 'No local audio backend is available. Run ./setup.sh again. ' + self.audio_backend_error}

    def recover_audio_backend(self) -> dict:
        """Restart the configured local player backend without changing settings."""
        requested = 'auto'
        result = self._init_audio_backend('auto')
        if result.get('ok'):
            result['volume'] = self._config.get('volume', 70)
            result['sound_preset'] = self._config.get('sound_preset', 'flat')
        return result

    def load_audio(self, path: str, autoplay: bool = True) -> dict:
        # A remote Chromium/ani-cli session must never permanently poison the
        # local player. If the selected backend died, restart it and retry once.
        if self.audio is None:
            recovery = self.recover_audio_backend()
            if not recovery.get('ok'):
                return self._audio_unavailable()

        first = self.audio.load(path, bool(autoplay))
        if first.get('ok'):
            return first

        first_error = str(first.get('error') or 'Local player failed.')
        recovery = self.recover_audio_backend()
        if not recovery.get('ok') or self.audio is None:
            first['recovery_attempted'] = True
            first['recovery_error'] = recovery.get('error', self.audio_backend_error)
            return first

        retry = self.audio.load(path, bool(autoplay))
        retry['recovery_attempted'] = True
        retry['recovered_backend'] = self.audio_backend
        if retry.get('ok'):
            retry['recovered'] = True
            retry['previous_error'] = first_error
            return retry

        retry['previous_error'] = first_error
        retry['error'] = (
            f"{retry.get('error') or 'Local playback failed after recovery.'} "
            f"(Initial error: {first_error})"
        )
        return retry

    def toggle_audio(self) -> dict:
        return self.audio.toggle() if self.audio is not None else self._audio_unavailable()

    def play_audio(self) -> dict:
        return self.audio.play() if self.audio is not None else self._audio_unavailable()

    def pause_audio(self) -> dict:
        return self.audio.pause() if self.audio is not None else self._audio_unavailable()

    def stop_audio(self) -> dict:
        return self.audio.stop() if self.audio is not None else {'ok': True}

    def seek_audio(self, seconds: float) -> dict:
        return self.audio.seek(seconds) if self.audio is not None else self._audio_unavailable()

    def seek_relative(self, delta_seconds: float) -> dict:
        return self.audio.seek_relative(delta_seconds) if self.audio is not None else self._audio_unavailable()

    def set_volume(self, percent: float) -> dict:
        if self.audio is None:
            try:
                value = max(0, min(200, int(float(percent))))
            except Exception:
                value = 70
            result = {'ok': False, 'volume': value, 'error': self.audio_backend_error}
        else:
            result = self.audio.set_volume(percent)
        self._config['volume'] = result.get('volume', 70)
        self._save_config()
        return result

    def audio_status(self) -> dict:
        return self.audio.status() if self.audio is not None else self._audio_unavailable()

    def playback_diagnostics(self) -> dict:
        runtime = dict(getattr(self, 'runtime_info', {}) or {})
        provider = getattr(self, 'runtime_diagnostics_provider', None)
        if callable(provider):
            try:
                extra = provider()
                if isinstance(extra, dict):
                    runtime.update(extra)
            except Exception:
                pass
        gst_elements = {}
        if GST_AVAILABLE:
            for name in ('playbin', 'autoaudiosink', 'pulsesink', 'pipewiresink', 'alsasink', 'decodebin'):
                try:
                    gst_elements[name] = bool(Gst.ElementFactory.find(name))
                except Exception:
                    gst_elements[name] = False
        return {
            'ok': True,
            'version': APP_VERSION,
            'audio_backend': self.audio_backend,
            'player_backend': 'auto',
            'sound_preset': self._config.get('sound_preset','flat'),
            'profile_name': self._config.get('profile_name','KLIGHTTEN User'),
            'profile_picture_data': self._profile_picture_data(),
            'floating_width': int(self._config.get('floating_width',620)),
            'floating_height': int(self._config.get('floating_height',460)),
            'audio_backend_error': self.audio_backend_error,
            'mpv_path': shutil.which('mpv') or '',
            'vlc_python': VLC_AVAILABLE,
            'ffmpeg_path': shutil.which('ffmpeg') or '',
            'ffprobe_path': shutil.which('ffprobe') or '',
            'gst_available': GST_AVAILABLE,
            'gst_import_error': GST_IMPORT_ERROR,
            'gst_elements': gst_elements,
            'pulse_server': os.environ.get('PULSE_SERVER', ''),
            'pipewire_runtime': bool(os.environ.get('XDG_RUNTIME_DIR')),
            'google_oauth_available': GOOGLE_AUTH_AVAILABLE,
            'google_oauth_import_error': GOOGLE_AUTH_IMPORT_ERROR,
            'youtube_oauth_client': OAUTH_CLIENT_FILE.exists(),
            'youtube_signed_in': bool(self._get_google_credentials()),
            'youtube_account_count': self.youtube_accounts_status(False).get('count',0),
            'media_api_count': len(self.media_api_providers().get('providers',[])),
            'ani_cli_in_app_pty': True, 'ani_terminal_emulator': 'pyte' if PYTE_AVAILABLE else 'fallback',
            'native_media_video': bool(shutil.which('mpv')),
            'youtube_app_id': YOUTUBE_APP_ID,
            'youtube_referer': YOUTUBE_REFERER,
            **runtime,
        }


    def _youtube_accounts_meta(self) -> list:
        return [x for x in list(self._config.get('youtube_accounts',[]) or []) if isinstance(x,dict)]

    def _account_token_path(self, account_id: str) -> Path:
        safe=re.sub(r'[^A-Za-z0-9_.-]+','_',str(account_id or 'account'))[:100]
        OAUTH_ACCOUNTS_DIR.mkdir(parents=True,exist_ok=True)
        return OAUTH_ACCOUNTS_DIR/f'{safe}.json'

    def _save_google_credentials(self, creds, account_id: str | None = None) -> None:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        path=self._account_token_path(account_id) if account_id else OAUTH_TOKEN_FILE
        path.write_text(creds.to_json(), encoding='utf-8')
        try: os.chmod(path,0o600)
        except OSError: pass

    def _get_google_credentials(self, account_id: str | None = None):
        if not GOOGLE_AUTH_AVAILABLE:
            return None
        chosen=str(account_id or self._config.get('active_youtube_account','') or '')
        path=None
        if chosen and chosen!='legacy':
            meta=next((x for x in self._youtube_accounts_meta() if x.get('id')==chosen),None)
            if meta:
                path=self._account_token_path(chosen)
        if path is None:
            if chosen=='legacy' or (not chosen and OAUTH_TOKEN_FILE.exists()):
                path=OAUTH_TOKEN_FILE
            elif self._youtube_accounts_meta():
                first=self._youtube_accounts_meta()[0]
                chosen=str(first.get('id','') or '')
                path=self._account_token_path(chosen)
        if path is None or not path.exists():
            return None
        try:
            creds=GoogleCredentials.from_authorized_user_file(str(path),YOUTUBE_READONLY_SCOPE)
            if creds.expired and creds.refresh_token:
                creds.refresh(GoogleAuthRequest())
                if path==OAUTH_TOKEN_FILE:self._save_google_credentials(creds)
                else:self._save_google_credentials(creds,chosen)
            if creds.valid:return creds
        except Exception:
            return None
        return None

    def _oauth_request_with_credentials(self, creds, endpoint: str, params: dict) -> dict:
        if creds is None:
            return {'ok':False,'needs_sign_in':True,'error':'Connect a YouTube account first.'}
        url=f'https://www.googleapis.com/youtube/v3/{endpoint}?' + urlencode(dict(params))
        req=Request(url,headers={'Authorization':f'Bearer {creds.token}','User-Agent':f'{APP_NAME}/{APP_VERSION}','Accept':'application/json'})
        try:
            with urlopen(req,timeout=15) as response:
                return {'ok':True,'payload':json.loads(response.read().decode('utf-8'))}
        except HTTPError as exc:
            detail='';reason=''
            try:
                body=json.loads(exc.read().decode('utf-8'))
                detail=body.get('error',{}).get('message','')
                errors=body.get('error',{}).get('errors',[])
                if errors: reason=errors[0].get('reason','')
            except Exception:pass
            if exc.code==401:return {'ok':False,'needs_sign_in':True,'error':'This YouTube sign-in expired. Connect it again.'}
            return {'ok':False,'error':detail or f'YouTube account API error {exc.code}.','reason':reason}
        except (URLError,TimeoutError):
            return {'ok':False,'error':'Could not reach YouTube. Check your internet connection.'}
        except Exception as exc:
            return {'ok':False,'error':f'YouTube account request failed: {exc}'}

    def _oauth_request(self, endpoint: str, params: dict, account_id: str | None = None) -> dict:
        return self._oauth_request_with_credentials(self._get_google_credentials(account_id),endpoint,params)

    def import_youtube_oauth_client(self) -> dict:
        if not GOOGLE_AUTH_AVAILABLE:return {'ok':False,'error':'Google OAuth support is missing. Run ./setup.sh again.'}
        if not self.window:return {'ok':False,'error':'Window is not ready.'}
        try:
            dialog_type=getattr(getattr(webview,'FileDialog',None),'LOAD',None)
            if dialog_type is None:dialog_type=getattr(webview,'OPEN_DIALOG',None)
            paths=self.window.create_file_dialog(dialog_type,allow_multiple=False,file_types=('Google OAuth JSON (*.json)','JSON Files (*.json)','All Files (*.*)'))
        except Exception as exc:return {'ok':False,'error':f'Credential picker failed: {exc}'}
        if not paths:return {'ok':True,'cancelled':True}
        source=Path(str(paths[0])).expanduser().resolve()
        try:data=json.loads(source.read_text(encoding='utf-8'))
        except Exception as exc:return {'ok':False,'error':f'Could not read OAuth JSON: {exc}'}
        installed=data.get('installed') if isinstance(data,dict) else None
        if not isinstance(installed,dict) or not installed.get('client_id'):
            return {'ok':False,'error':'This is not a Google Desktop app OAuth JSON.'}
        CONFIG_DIR.mkdir(parents=True,exist_ok=True)
        OAUTH_CLIENT_FILE.write_text(json.dumps({'installed':installed},indent=2),encoding='utf-8')
        try:os.chmod(OAUTH_CLIENT_FILE,0o600)
        except OSError:pass
        return {'ok':True,'configured':True,'project_id':installed.get('project_id','')}

    def connect_youtube_account(self) -> dict:
        if not GOOGLE_AUTH_AVAILABLE:return {'ok':False,'error':'Google OAuth support is missing. Run ./setup.sh again.'}
        if not OAUTH_CLIENT_FILE.exists():return {'ok':False,'needs_oauth_client':True,'error':'Import a Google Desktop OAuth client JSON first.'}
        count=len(self._youtube_accounts_meta())+(1 if OAUTH_TOKEN_FILE.exists() else 0)
        if count>=5:return {'ok':False,'error':'KLIGHTTEN MEDIA supports up to 5 YouTube accounts.'}
        try:
            flow=InstalledAppFlow.from_client_secrets_file(str(OAUTH_CLIENT_FILE),scopes=YOUTUBE_READONLY_SCOPE)
            creds=flow.run_local_server(host='127.0.0.1',port=0,open_browser=True,
                authorization_prompt_message='Opening Google sign-in in your browser…',
                success_message='KLIGHTTEN MEDIA connected this YouTube account. You can close this browser tab.',
                access_type='offline',prompt='consent')
            prof=self._oauth_request_with_credentials(creds,'channels',{'part':'snippet,contentDetails','mine':'true','maxResults':'1'})
            item=(prof.get('payload',{}).get('items') or [{}])[0] if prof.get('ok') else {}
            snippet=item.get('snippet',{});thumbs=snippet.get('thumbnails',{});related=item.get('contentDetails',{}).get('relatedPlaylists',{})
            account_id=item.get('id') or ('acct_'+uuid.uuid4().hex[:12])
            meta={
                'id':account_id,'title':html.unescape(snippet.get('title','YouTube account')),
                'channel_id':item.get('id',''),'thumbnail':thumbs.get('medium',{}).get('url') or thumbs.get('default',{}).get('url') or '',
                'likes_playlist_id':related.get('likes',''),
            }
            self._save_google_credentials(creds,account_id)
            accounts=[x for x in self._youtube_accounts_meta() if x.get('id')!=account_id]
            accounts.append(meta)
            self._config['youtube_accounts']=accounts[:5]
            self._config['active_youtube_account']=account_id
            self._save_config()
        except Exception as exc:
            return {'ok':False,'error':f'YouTube sign-in failed: {exc}'}
        return self.youtube_accounts_status(True)

    def switch_youtube_account(self, account_id: str) -> dict:
        account_id=str(account_id or '')
        valid={x.get('id') for x in self._youtube_accounts_meta()}
        if OAUTH_TOKEN_FILE.exists():valid.add('legacy')
        if account_id not in valid:return {'ok':False,'error':'YouTube account not found.'}
        self._config['active_youtube_account']=account_id;self._save_config()
        return self.youtube_account_status(True)

    def disconnect_youtube_account(self, account_id: str = '') -> dict:
        target=str(account_id or self._config.get('active_youtube_account','') or '')
        creds=self._get_google_credentials(target)
        if creds is not None and getattr(creds,'token',None):
            try:
                data=urlencode({'token':creds.token}).encode('utf-8')
                with urlopen(Request('https://oauth2.googleapis.com/revoke',data=data,headers={'Content-Type':'application/x-www-form-urlencoded'}),timeout=10):pass
            except Exception:pass
        if target=='legacy' or (not target and OAUTH_TOKEN_FILE.exists()):
            try:OAUTH_TOKEN_FILE.unlink(missing_ok=True)
            except Exception:pass
        else:
            try:self._account_token_path(target).unlink(missing_ok=True)
            except Exception:pass
            self._config['youtube_accounts']=[x for x in self._youtube_accounts_meta() if x.get('id')!=target]
        remaining=self._youtube_accounts_meta()
        self._config['active_youtube_account']=remaining[0].get('id','') if remaining else ('legacy' if OAUTH_TOKEN_FILE.exists() else '')
        self._save_config()
        return self.youtube_accounts_status(False)

    def youtube_accounts_status(self, include_profiles: bool = False) -> dict:
        accounts=[]
        if OAUTH_TOKEN_FILE.exists():
            legacy={'id':'legacy','title':'Connected YouTube account','channel_id':'','thumbnail':'','legacy':True}
            if include_profiles:
                creds=self._get_google_credentials('legacy')
                r=self._oauth_request_with_credentials(creds,'channels',{'part':'snippet,contentDetails','mine':'true','maxResults':'1'})
                items=r.get('payload',{}).get('items',[]) if r.get('ok') else []
                if items:
                    it=items[0];sn=it.get('snippet',{});th=sn.get('thumbnails',{});rel=it.get('contentDetails',{}).get('relatedPlaylists',{})
                    legacy.update({'title':html.unescape(sn.get('title','YouTube account')),'channel_id':it.get('id',''),'thumbnail':th.get('medium',{}).get('url') or th.get('default',{}).get('url') or '','likes_playlist_id':rel.get('likes','')})
            accounts.append(legacy)
        accounts.extend(self._youtube_accounts_meta())
        active=str(self._config.get('active_youtube_account','') or '')
        if not active and accounts:active=accounts[0].get('id','')
        return {'ok':True,'accounts':accounts[:5],'active_account':active,'count':len(accounts[:5]),'max_accounts':5,
                'oauth_available':GOOGLE_AUTH_AVAILABLE,'configured_client':OAUTH_CLIENT_FILE.exists()}

    def youtube_account_status(self, include_profile: bool = True) -> dict:
        configured=OAUTH_CLIENT_FILE.exists()
        creds=self._get_google_credentials()
        active=str(self._config.get('active_youtube_account','') or '')
        base={'ok':True,'oauth_available':GOOGLE_AUTH_AVAILABLE,'oauth_import_error':GOOGLE_AUTH_IMPORT_ERROR,
              'configured_client':configured,'signed_in':bool(creds),'active_account':active}
        if not creds or not include_profile:return base
        result=self._oauth_request('channels',{'part':'snippet,contentDetails','mine':'true','maxResults':'1'})
        if not result.get('ok'):
            base.update({'signed_in':False,'error':result.get('error','Could not read YouTube account.')});return base
        items=result.get('payload',{}).get('items',[])
        if not items:
            base['profile']={'title':'YouTube account','channel_id':'','thumbnail':'','likes_playlist_id':''};return base
        item=items[0];snippet=item.get('snippet',{});thumbs=snippet.get('thumbnails',{});related=item.get('contentDetails',{}).get('relatedPlaylists',{})
        base['profile']={'title':html.unescape(snippet.get('title','YouTube account')),'channel_id':item.get('id',''),
                         'thumbnail':thumbs.get('medium',{}).get('url') or thumbs.get('default',{}).get('url') or '',
                         'likes_playlist_id':related.get('likes','')}
        return base

    def youtube_account_playlists(self) -> dict:
        status = self.youtube_account_status(include_profile=True)
        if not status.get('signed_in'):
            return {'ok': False, 'needs_sign_in': True, 'error': status.get('error', 'Connect your YouTube account first.')}
        profile = status.get('profile', {})
        result = self._oauth_request('playlists', {
            'part': 'snippet,contentDetails', 'mine': 'true', 'maxResults': '50'
        })
        if not result.get('ok'):
            return result
        playlists = []
        likes_id = profile.get('likes_playlist_id', '')
        if likes_id:
            playlists.append({
                'id': likes_id, 'title': 'Liked Videos', 'description': 'Videos you liked on YouTube',
                'thumbnail': profile.get('thumbnail', ''), 'item_count': None, 'system': 'likes'
            })
        for item in result.get('payload', {}).get('items', []):
            snippet = item.get('snippet', {})
            thumbs = snippet.get('thumbnails', {})
            playlists.append({
                'id': item.get('id', ''),
                'title': html.unescape(snippet.get('title', 'Playlist')),
                'description': html.unescape(snippet.get('description', '') or ''),
                'thumbnail': thumbs.get('medium', {}).get('url') or thumbs.get('high', {}).get('url') or thumbs.get('default', {}).get('url') or '',
                'item_count': item.get('contentDetails', {}).get('itemCount'),
                'system': '',
            })
        return {'ok': True, 'profile': profile, 'playlists': playlists}

    def youtube_account_subscriptions(self, max_results: int = 24) -> dict:
        try:
            max_results = max(1, min(int(max_results), 50))
        except Exception:
            max_results = 24
        result = self._oauth_request('subscriptions', {
            'part': 'snippet', 'mine': 'true', 'order': 'alphabetical', 'maxResults': str(max_results)
        })
        if not result.get('ok'):
            return result
        items = []
        for item in result.get('payload', {}).get('items', []):
            snippet = item.get('snippet', {})
            resource = snippet.get('resourceId', {})
            thumbs = snippet.get('thumbnails', {})
            items.append({
                'channel_id': resource.get('channelId', ''),
                'title': html.unescape(snippet.get('title', 'Channel')),
                'thumbnail': thumbs.get('medium', {}).get('url') or thumbs.get('default', {}).get('url') or '',
            })
        return {'ok': True, 'subscriptions': items}

    def youtube_playlist_tracks(self, playlist_id: str, max_items: int = 100) -> dict:
        playlist_id = (playlist_id or '').strip()
        if not playlist_id or len(playlist_id) > 160:
            return {'ok': False, 'error': 'Invalid playlist ID.'}
        try:
            max_items = max(1, min(int(max_items), 200))
        except Exception:
            max_items = 100
        raw = []
        token = ''
        while len(raw) < max_items:
            params = {
                'part': 'snippet,contentDetails', 'playlistId': playlist_id,
                'maxResults': str(min(50, max_items - len(raw)))
            }
            if token:
                params['pageToken'] = token
            result = self._oauth_request('playlistItems', params)
            if not result.get('ok'):
                return result
            payload = result.get('payload', {})
            raw.extend(payload.get('items', []))
            token = payload.get('nextPageToken', '')
            if not token:
                break
        ids = []
        base_by_id = {}
        for item in raw[:max_items]:
            snippet = item.get('snippet', {})
            content = item.get('contentDetails', {})
            video_id = content.get('videoId') or snippet.get('resourceId', {}).get('videoId')
            if not video_id or video_id in base_by_id:
                continue
            title = snippet.get('title', '')
            if title in {'Deleted video', 'Private video'}:
                continue
            thumbs = snippet.get('thumbnails', {})
            owner = snippet.get('videoOwnerChannelTitle') or snippet.get('channelTitle') or 'YouTube'
            base_by_id[video_id] = {
                'id': f'youtube:{video_id}', 'kind': 'youtube', 'video_id': video_id,
                'title': html.unescape(title or 'YouTube video'),
                'artist': html.unescape(owner), 'channel': html.unescape(owner),
                'thumbnail': thumbs.get('medium', {}).get('url') or thumbs.get('high', {}).get('url') or thumbs.get('default', {}).get('url') or f'https://i.ytimg.com/vi/{video_id}/mqdefault.jpg',
                'artwork': thumbs.get('medium', {}).get('url') or thumbs.get('high', {}).get('url') or thumbs.get('default', {}).get('url') or f'https://i.ytimg.com/vi/{video_id}/mqdefault.jpg',
                'url': f'https://www.youtube.com/watch?v={video_id}', 'source': 'YouTube',
            }
            ids.append(video_id)
        playable = []
        for start in range(0, len(ids), 50):
            batch = ids[start:start+50]
            vr = self._oauth_request('videos', {'part': 'snippet,status,contentDetails', 'id': ','.join(batch)})
            if not vr.get('ok'):
                return vr
            for item in vr.get('payload', {}).get('items', []):
                video_id = item.get('id', '')
                status = item.get('status', {})
                if not status.get('embeddable', False):
                    continue
                track = dict(base_by_id.get(video_id, {}))
                if not track:
                    continue
                snippet = item.get('snippet', {})
                thumbs = snippet.get('thumbnails', {})
                track['title'] = html.unescape(snippet.get('title', track.get('title', 'YouTube video')))
                channel = html.unescape(snippet.get('channelTitle', track.get('artist', 'YouTube')))
                track['artist'] = channel
                track['channel'] = channel
                better_thumb = thumbs.get('medium', {}).get('url') or thumbs.get('high', {}).get('url') or ''
                if better_thumb:
                    track['thumbnail'] = better_thumb
                    track['artwork'] = better_thumb
                playable.append(track)
        order = {vid: i for i, vid in enumerate(ids)}
        playable.sort(key=lambda t: order.get(t.get('video_id'), 10**9))
        return {'ok': True, 'tracks': playable, 'requested': len(raw), 'playable': len(playable)}

    def _youtube_request(self, endpoint: str, params: dict) -> dict:
        api_key = self._config.get('youtube_api_key', '').strip()
        creds = self._get_google_credentials()
        if not api_key and creds is None:
            return {
                'ok': False,
                'needs_api_key': True,
                'needs_sign_in': True,
                'error': 'Add a YouTube Data API key or connect your YouTube account.',
            }
        query = dict(params)
        headers = {'User-Agent': f'{APP_NAME}/{APP_VERSION}', 'Accept': 'application/json'}
        if api_key:
            query['key'] = api_key
        elif creds is not None:
            headers['Authorization'] = f'Bearer {creds.token}'
        url = f'https://www.googleapis.com/youtube/v3/{endpoint}?' + urlencode(query)
        req = Request(url, headers=headers)
        try:
            with urlopen(req, timeout=12) as response:
                return {'ok': True, 'payload': json.loads(response.read().decode('utf-8'))}
        except HTTPError as exc:
            detail = ''
            try:
                body = json.loads(exc.read().decode('utf-8'))
                detail = body.get('error', {}).get('message', '')
            except Exception:
                pass
            return {'ok': False, 'error': detail or f'YouTube API error {exc.code}.'}
        except (URLError, TimeoutError):
            return {'ok': False, 'error': 'Could not reach YouTube. Check your internet connection.'}
        except Exception as exc:
            return {'ok': False, 'error': f'YouTube request failed: {exc}'}

    def youtube_video_info(self, video_id: str) -> dict:
        video_id = (video_id or '').strip()
        if not re.fullmatch(r'[A-Za-z0-9_-]{11}', video_id):
            return {'ok': False, 'error': 'Invalid YouTube video ID.'}
        api_key = self._config.get('youtube_api_key', '').strip()
        if not api_key:
            return {
                'ok': True,
                'unverified': True,
                'track': {
                    'id': f'youtube:{video_id}', 'kind': 'youtube', 'video_id': video_id,
                    'title': 'YouTube video', 'artist': 'YouTube', 'channel': 'YouTube',
                    'thumbnail': f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg',
                    'artwork': f'https://i.ytimg.com/vi/{video_id}/hqdefault.jpg',
                    'url': f'https://www.youtube.com/watch?v={video_id}', 'source': 'YouTube',
                },
            }
        result = self._youtube_request('videos', {'part': 'snippet,status', 'id': video_id})
        if not result.get('ok'):
            return result
        items = result.get('payload', {}).get('items', [])
        if not items:
            return {'ok': False, 'error': 'YouTube video not found.'}
        item = items[0]
        status = item.get('status', {})
        if not status.get('embeddable', False):
            return {'ok': False, 'error': 'This YouTube video does not allow embedded playback.'}
        snippet = item.get('snippet', {})
        thumbs = snippet.get('thumbnails', {})
        thumb = thumbs.get('high', {}).get('url') or thumbs.get('medium', {}).get('url') or thumbs.get('default', {}).get('url') or ''
        return {
            'ok': True,
            'track': {
                'id': f'youtube:{video_id}', 'kind': 'youtube', 'video_id': video_id,
                'title': html.unescape(snippet.get('title', 'Untitled')),
                'artist': html.unescape(snippet.get('channelTitle', 'YouTube')),
                'channel': html.unescape(snippet.get('channelTitle', 'YouTube')),
                'thumbnail': thumb, 'artwork': thumb,
                'url': f'https://www.youtube.com/watch?v={video_id}', 'source': 'YouTube',
            },
        }

    def search_youtube(self, query: str, max_results: int = 12) -> dict:
        query = (query or '').strip()
        if not query:
            return {'ok': False, 'error': 'Type something to search.'}
        try:
            max_results = max(1, min(int(max_results), 15))
        except (TypeError, ValueError):
            max_results = 12
        search_result = self._youtube_request(
            'search',
            {
                'part': 'snippet', 'type': 'video', 'videoEmbeddable': 'true',
                'videoCategoryId': '10', 'safeSearch': 'moderate',
                'maxResults': str(max_results), 'q': query,
            },
        )
        if not search_result.get('ok'):
            return search_result
        raw_items = search_result.get('payload', {}).get('items', [])
        ids = [item.get('id', {}).get('videoId') for item in raw_items if item.get('id', {}).get('videoId')]
        if not ids:
            return {'ok': True, 'results': []}
        status_result = self._youtube_request('videos', {'part': 'status', 'id': ','.join(ids)})
        if not status_result.get('ok'):
            return status_result
        status_by_id = {item.get('id'): item.get('status', {}) for item in status_result.get('payload', {}).get('items', [])}
        results = []
        for item in raw_items:
            video_id = item.get('id', {}).get('videoId')
            if not video_id:
                continue
            status = status_by_id.get(video_id, {})
            if not status.get('embeddable', False):
                continue
            snippet = item.get('snippet', {})
            thumbs = snippet.get('thumbnails', {})
            thumb = thumbs.get('medium', {}).get('url') or thumbs.get('high', {}).get('url') or thumbs.get('default', {}).get('url') or ''
            channel = html.unescape(snippet.get('channelTitle', 'YouTube'))
            results.append({
                'id': f'youtube:{video_id}', 'kind': 'youtube', 'video_id': video_id,
                'title': html.unescape(snippet.get('title', 'Untitled')),
                'artist': channel, 'channel': channel, 'thumbnail': thumb, 'artwork': thumb,
                'url': f'https://www.youtube.com/watch?v={video_id}', 'source': 'YouTube',
            })
        return {'ok': True, 'results': results}

    def set_floating_video(self, enabled: bool) -> dict:
        if not self.window:
            return {'ok': False, 'error': 'Window is not ready.'}
        enabled = bool(enabled)
        try:
            if enabled and not self._floating_video:
                # Save the normal geometry so the full app can be restored exactly.
                self._floating_geometry = {
                    'x': int(self.window.x),
                    'y': int(self.window.y),
                    'width': int(self.window.width),
                    'height': int(self.window.height),
                    'maximized': bool(self._maximized),
                }
                if self._maximized:
                    self.window.restore()
                    self._maximized = False
                self.window.on_top = True
                float_w=max(360,min(1400,int(self._config.get('floating_width',620))))
                float_h=max(260,min(1000,int(self._config.get('floating_height',460))))
                self.window.resize(float_w, float_h)
                try:
                    if hasattr(self.window, 'move_to_floating_corner'):
                        self.window.move_to_floating_corner(float_w, float_h)
                    elif webview is not None:
                        screens = webview.screens
                        if screens:
                            screen = screens[0]
                            x = max(12, int(screen.width) - float_w - 24)
                            y = max(12, int(screen.height) - float_h - 56)
                            self.window.move(x, y)
                except Exception:
                    pass
                self._floating_video = True
            elif not enabled and self._floating_video:
                self.window.on_top = False
                geo = self._floating_geometry or {}
                width = max(980, int(geo.get('width', 1260)))
                height = max(650, int(geo.get('height', 820)))
                self.window.resize(width, height)
                try:
                    self.window.move(int(geo.get('x', 80)), int(geo.get('y', 80)))
                except Exception:
                    pass
                if geo.get('maximized'):
                    self.window.maximize()
                    self._maximized = True
                self._floating_video = False
                self._floating_geometry = None
            return {'ok': True, 'floating': self._floating_video}
        except Exception as exc:
            return {'ok': False, 'error': f'Could not change floating-player mode: {exc}'}

    def start_drag(self) -> dict:
        if self.window and hasattr(self.window, 'start_drag'):
            try:
                return {'ok': True, 'started': bool(self.window.start_drag())}
            except Exception as exc:
                return {'ok': False, 'error': f'Could not start window drag: {exc}'}
        return {'ok': False, 'error': 'Window dragging is unavailable.'}

    def hide_to_tray(self) -> dict:
        if self.window and hasattr(self.window,'hide_to_tray'):
            self.window.hide_to_tray(); return {'ok':True,'hidden':True}
        if self.window: self.window.minimize()
        return {'ok':True,'hidden':False}

    def minimize(self) -> dict:
        if self.window:
            self.window.minimize()
        return {'ok': True}

    def toggle_maximize(self) -> dict:
        if not self.window:
            return {'ok': False}
        if self._maximized:
            self.window.restore()
        else:
            self.window.maximize()
        self._maximized = not self._maximized
        return {'ok': True, 'maximized': self._maximized}

    def close(self) -> dict:
        with self._conversion_lock:
            processes = list(self._conversion_processes.values())
        for process in processes:
            try:
                if process.poll() is None:
                    process.terminate()
            except Exception:
                pass
        if self.audio is not None and hasattr(self.audio, 'shutdown'):
            try:
                self.audio.shutdown()
            except Exception:
                pass
        if self.window:
            self.window.destroy()
        return {'ok': True}

    def open_external(self, url: str) -> dict:
        allowed_hosts = {
            'www.youtube.com', 'youtube.com', 'youtu.be', 'studio.youtube.com', 'developers.google.com',
            'console.cloud.google.com', 'policies.google.com', 'github.com',
        }
        try:
            parsed = urlparse(url)
            if parsed.scheme != 'https' or parsed.hostname not in allowed_hosts:
                return {'ok': False, 'error': 'Blocked external URL.'}
            webbrowser.open(url)
            return {'ok': True}
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}



class AppHTTPHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        super().end_headers()

    def log_message(self, format, *args):
        return


def start_local_app_server():
    handler = partial(AppHTTPHandler, directory=str(BASE_DIR))
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, name='klightten-http', daemon=True)
    thread.start()
    host, port = server.server_address[:2]
    return server, f'http://{host}:{port}/ui/index.html'

def main() -> int:
    if webview is None:
        print('Legacy pywebview shell is not installed. Run qt_shell.py / ./run.sh for KLIGHTTEN MEDIA 2.0.')
        return 1
    if not UI_FILE.exists():
        print(f'UI file not found: {UI_FILE}')
        return 1
    server, app_url = start_local_app_server()
    api = AppAPI()
    window = webview.create_window(
        APP_NAME,
        app_url,
        js_api=api,
        width=1260,
        height=820,
        min_size=(460, 340),
        frameless=True,
        easy_drag=False,
        resizable=True,
        background_color='#050611',
        text_select=False,
    )
    api.bind_window(window)

    def pause_youtube_if_hidden(*_args):
        try:
            window.evaluate_js('window.pauseYouTubeForWindowState && window.pauseYouTubeForWindowState();')
        except Exception:
            pass

    try:
        window.events.minimized += pause_youtube_if_hidden
    except Exception:
        pass

    try:
        webview.start()
    finally:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
        if api.audio is not None and hasattr(api.audio, 'shutdown'):
            try:
                api.audio.shutdown()
            except Exception:
                pass
    return 0


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env bash
set -u

echo "KLIGHTTEN MEDIA 2.3 - Media Hub Diagnostics"
echo "=========================================="
echo

echo "[1] Qt WebEngine / Chromium"
if [[ -x .venv/bin/python ]]; then
  .venv/bin/python - <<'PY'
import sys
print('Python:', sys.version.split()[0])
try:
    from PyQt6.QtCore import QT_VERSION_STR
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    print('Qt shell: PyQt6 OK')
    print('Qt version:', QT_VERSION_STR)
except Exception as e6:
    try:
        from PyQt5.QtCore import QT_VERSION_STR
        from PyQt5.QtWebEngineWidgets import QWebEngineView
        print('Qt shell: PyQt5 OK')
        print('Qt version:', QT_VERSION_STR)
    except Exception as e5:
        print('Qt WebEngine: ERROR')
        print('PyQt6:', e6)
        print('PyQt5:', e5)
print('YouTube app ID: io.github.jardeleza0921.klighttenmedia')
print('YouTube Referer: https://io.github.jardeleza0921.klighttenmedia/')
PY
else
  echo "No .venv yet. Run ./setup.sh"
fi

echo
echo "[2] MPV"
if command -v mpv >/dev/null 2>&1; then
  echo "OK: $(command -v mpv)"
  mpv --version | head -1
else
  echo "MISSING: mpv"
fi

echo
echo "[3] Alternate local players"
for c in vlc celluloid playerctl; do
  if command -v "$c" >/dev/null 2>&1; then echo "OK: $c -> $(command -v $c)"; else echo "MISSING: $c"; fi
done

echo
echo "[4] Audio server"
if command -v wpctl >/dev/null 2>&1; then
  wpctl status 2>/dev/null | sed -n '1,35p'
elif command -v pactl >/dev/null 2>&1; then
  pactl info 2>/dev/null | grep -E 'Server Name|Default Sink|Default Source' || true
else
  echo "No wpctl/pactl command found."
fi

echo
echo "[5] GStreamer"
if command -v gst-inspect-1.0 >/dev/null 2>&1; then
  for e in playbin autoaudiosink pulsesink pipewiresink alsasink decodebin; do
    if gst-inspect-1.0 "$e" >/dev/null 2>&1; then echo "OK: $e"; else echo "MISSING: $e"; fi
  done
else
  echo "MISSING: gst-inspect-1.0"
fi

echo
echo "[6] Google OAuth"
if [[ -x .venv/bin/python ]]; then
  .venv/bin/python - <<'PY'
try:
    import google.auth
    import google_auth_oauthlib
    print('Google OAuth: OK')
except Exception as exc:
    print('Google OAuth: ERROR', exc)
PY
fi

echo
echo "If Qt WebEngine or MPV says MISSING/ERROR, run: ./setup.sh"

echo
echo '== Converter =='
command -v ffmpeg >/dev/null 2>&1 && echo "ffmpeg: $(ffmpeg -version | head -1)" || echo 'ffmpeg: MISSING'
command -v ffprobe >/dev/null 2>&1 && echo "ffprobe: $(ffprobe -version | head -1)" || echo 'ffprobe: MISSING'


echo
echo "[7] Plugins / ani-cli"
if command -v ani-cli >/dev/null 2>&1; then
  echo "ani-cli: $(command -v ani-cli)"
  ani-cli -V 2>/dev/null | head -1 || true
else
  echo "ani-cli: NOT INSTALLED (can be added later in Settings > Plugins)"
fi

echo "pyte terminal emulator:"
python -c "import pyte; print(pyte.__version__ if hasattr(pyte, '__version__') else 'installed')" 2>/dev/null || echo "NOT INSTALLED - run ./setup.sh"


echo
echo "[KLIGHTTEN 2.5 Playback]"
echo "Automatic player: MPV (GStreamer emergency audio fallback only)"

#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import sys
import traceback
import shutil
import socket
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor

# Keep Chromium/WebEngine dark from the first rendered frame.  The web UI has
# its own KLIGHTTEN themes; this only prevents Qt/Chromium chrome and loading
# surfaces from flashing white around it.
_qt_chromium_flags = os.environ.get('QTWEBENGINE_CHROMIUM_FLAGS', '')
for _flag in ('--force-dark-mode', '--enable-features=WebUIDarkMode'):
    if _flag not in _qt_chromium_flags:
        _qt_chromium_flags = (_qt_chromium_flags + ' ' + _flag).strip()
os.environ['QTWEBENGINE_CHROMIUM_FLAGS'] = _qt_chromium_flags

# Avoid the Qt Quick QRhiGles2/non-OpenGL-surface conflict caused by the
# native MPV video target. This affects Qt Quick only; Chromium keeps its own
# WebEngine rendering configuration.
os.environ['QT_QUICK_BACKEND'] = 'software'

from pathlib import Path

import main as core

APP_ID = core.YOUTUBE_APP_ID
YOUTUBE_REFERER = core.YOUTUBE_REFERER

QT_API = None
try:
    from PyQt6.QtCore import QObject, QUrl, QByteArray, QPoint, pyqtSignal as Signal, pyqtSlot as Slot, Qt, QEvent
    from PyQt6.QtGui import QColor, QPalette, QIcon, QAction
    from PyQt6.QtWidgets import QApplication, QMainWindow, QFileDialog, QSystemTrayIcon, QMenu, QWidget
    from PyQt6.QtWebChannel import QWebChannel
    from PyQt6.QtWebEngineCore import (
        QWebEnginePage, QWebEngineProfile, QWebEngineSettings,
        QWebEngineUrlRequestInterceptor,
    )
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    QT_API = 'PyQt6'
except Exception:
    from PyQt5.QtCore import QObject, QUrl, QByteArray, QPoint, pyqtSignal as Signal, pyqtSlot as Slot, Qt, QEvent
    from PyQt5.QtGui import QColor, QPalette, QIcon
    from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QSystemTrayIcon, QMenu, QAction, QWidget
    from PyQt5.QtWebChannel import QWebChannel
    from PyQt5.QtWebEngineCore import (
        QWebEnginePage, QWebEngineProfile, QWebEngineSettings,
        QWebEngineUrlRequestInterceptor,
    )
    from PyQt5.QtWebEngineWidgets import QWebEngineView
    QT_API = 'PyQt5'




def _palette_role(name: str):
    enum = getattr(QPalette, 'ColorRole', None)
    if enum is not None:
        return getattr(enum, name)
    return getattr(QPalette, name)


def apply_dark_qt_palette(app: QApplication) -> None:
    """Darken native Qt surfaces used around the HTML/Chromium content."""
    try:
        app.setStyle('Fusion')
    except Exception:
        pass
    palette = QPalette()
    values = {
        'Window': '#050611',
        'WindowText': '#ecfbff',
        'Base': '#050611',
        'AlternateBase': '#090c1f',
        'ToolTipBase': '#0d1030',
        'ToolTipText': '#ecfbff',
        'Text': '#ecfbff',
        'Button': '#090c1f',
        'ButtonText': '#ecfbff',
        'BrightText': '#ffffff',
        'Highlight': '#00e7ff',
        'HighlightedText': '#03040b',
        'PlaceholderText': '#7d9bbb',
    }
    for role_name, value in values.items():
        try:
            palette.setColor(_palette_role(role_name), QColor(value))
        except Exception:
            pass
    try:
        app.setPalette(palette)
    except Exception:
        pass


def _qt_frameless_flag():
    return getattr(getattr(Qt, 'WindowType', Qt), 'FramelessWindowHint')


def _qt_on_top_flag():
    return getattr(getattr(Qt, 'WindowType', Qt), 'WindowStaysOnTopHint')


def _qt_tool_flag():
    return getattr(getattr(Qt, 'WindowType', Qt), 'Tool')


def _qt_no_focus_flag():
    return getattr(getattr(Qt, 'WindowType', Qt), 'WindowDoesNotAcceptFocus', 0)


def _qt_transparent_input_flag():
    return getattr(getattr(Qt, 'WindowType', Qt), 'WindowTransparentForInput', 0)


def _qt_edge(name: str):
    edge_enum = getattr(Qt, 'Edge', Qt)
    mapping = {
        'left': 'LeftEdge', 'right': 'RightEdge',
        'top': 'TopEdge', 'bottom': 'BottomEdge',
    }
    return getattr(edge_enum, mapping[name])


def _event_window_state_change():
    return getattr(getattr(QEvent, 'Type', QEvent), 'WindowStateChange')


def _web_attribute(name: str):
    enum = getattr(QWebEngineSettings, 'WebAttribute', None)
    if enum is not None:
        return getattr(enum, name)
    return getattr(QWebEngineSettings, name)


class YouTubeIdentityInterceptor(QWebEngineUrlRequestInterceptor):
    """Attach the stable Linux app identity YouTube requires for desktop WebViews."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.last_youtube_url = ''
        self.youtube_request_count = 0
        self.media_referrers = {}

    def add_media_referrer(self, media_url: str, referrer: str = ''):
        try:
            url=QUrl(str(media_url or ''))
            host=(url.host() or '').lower()
            if host:
                self.media_referrers[host]=str(referrer or '')
        except Exception:
            pass

    def interceptRequest(self, info):
        try:
            url = info.requestUrl()
            host = (url.host() or '').lower()
            if (
                host == 'youtube.com' or host.endswith('.youtube.com') or
                host == 'youtube-nocookie.com' or host.endswith('.youtube-nocookie.com')
            ):
                info.setHttpHeader(QByteArray(b'Referer'), QByteArray(YOUTUBE_REFERER.encode('utf-8')))
                self.last_youtube_url = url.toString()
                self.youtube_request_count += 1
            elif host in self.media_referrers:
                ref=self.media_referrers.get(host,'')
                if ref:
                    info.setHttpHeader(QByteArray(b'Referer'), QByteArray(ref.encode('utf-8')))
        except Exception:
            pass


class QtWindowAdapter:
    """Small compatibility layer used by the existing KLIGHTTEN Python API."""

    def __init__(self, window: 'KlighttenWindow'):
        self._window = window

    @property
    def x(self):
        return self._window.x()

    @property
    def y(self):
        return self._window.y()

    @property
    def width(self):
        return self._window.width()

    @property
    def height(self):
        return self._window.height()

    @property
    def on_top(self):
        return bool(self._window.windowFlags() & _qt_on_top_flag())

    @on_top.setter
    def on_top(self, enabled):
        self._window.setWindowFlag(_qt_on_top_flag(), bool(enabled))
        self._window.show()

    def minimize(self):
        self._window.showMinimized()

    def hide_to_tray(self):
        self._window.hide_to_tray()

    def show_from_tray(self):
        self._window.restore_from_tray()

    def restore(self):
        self._window.showNormal()

    def maximize(self):
        self._window.showMaximized()

    def resize(self, width, height):
        self._window.resize(int(width), int(height))

    def move(self, x, y):
        self._window.move(int(x), int(y))

    def destroy(self):
        self._window.close()

    def start_drag(self):
        try:
            handle = self._window.windowHandle()
            if handle is not None and hasattr(handle, 'startSystemMove'):
                return bool(handle.startSystemMove())
        except Exception:
            pass
        return False

    def start_resize(self, edge='bottom-right'):
        try:
            handle = self._window.windowHandle()
            if handle is None or not hasattr(handle, 'startSystemResize'):
                return False
            edge = str(edge or 'bottom-right').lower()
            flag = None
            if edge in ('left','right','top','bottom'):
                flag = _qt_edge(edge)
            else:
                parts = edge.split('-')
                for part in parts:
                    if part in ('left','right','top','bottom'):
                        flag = _qt_edge(part) if flag is None else (flag | _qt_edge(part))
            return bool(handle.startSystemResize(flag)) if flag is not None else False
        except Exception:
            return False

    def move_to_floating_corner(self, width=620, height=460):
        try:
            screen = self._window.screen()
            geo = screen.availableGeometry() if screen is not None else None
            if geo is None:
                return False
            x = max(12, geo.x() + geo.width() - int(width) - 24)
            y = max(12, geo.y() + geo.height() - int(height) - 24)
            self._window.move(x, y)
            return True
        except Exception:
            return False

    def set_media_fullscreen(self, enabled=False):
        return self._window.set_media_fullscreen(bool(enabled))

    def media_fullscreen_status(self):
        return self._window.media_fullscreen_status()

    def load_remote_video(self, url, referrer='', args=None, autoplay=True, volume=70):
        return self._window.load_remote_video(url, referrer, args or [], autoplay, volume)

    def control_remote_video(self, action, value=0):
        return self._window.control_remote_video(action, value)

    def remote_video_status(self):
        return self._window.remote_video_status()

    def set_remote_video_geometry(self, x, y, width, height, visible=True):
        return self._window.set_remote_video_geometry(x, y, width, height, visible)

    def stop_remote_video(self):
        return self._window.stop_remote_video()

    def create_file_dialog(self, dialog_type=None, allow_multiple=False, file_types=None, **kwargs):
        # In the current API, no file_types means a folder picker.
        if not file_types:
            title = str(kwargs.get('title') or 'Choose Folder')
            path = QFileDialog.getExistingDirectory(self._window, title, str(Path.home()))
            return [path] if path else []

        filters = []
        for value in file_types:
            text = str(value).replace(';', ' ')
            filters.append(text)
        filter_text = ';;'.join(filters) if filters else 'All Files (*)'
        if allow_multiple:
            title = str(kwargs.get('title') or 'Choose Files')
            paths, _ = QFileDialog.getOpenFileNames(self._window, title, str(Path.home()), filter_text)
        else:
            title = str(kwargs.get('title') or 'Choose File')
            path, _ = QFileDialog.getOpenFileName(self._window, title, str(Path.home()), filter_text)
            paths = [path] if path else []
        return paths


class APIBridge(QObject):
    resultReady = Signal(str, str)

    # Methods that must execute on Qt's GUI thread because they show dialogs or mutate the window.
    GUI_METHODS = {
        'choose_audio_files', 'choose_music_folder', 'choose_converter_input',
        'choose_converter_output_folder', 'import_youtube_oauth_client',
        'set_floating_video', 'save_floating_size', 'minimize', 'hide_to_tray', 'toggle_maximize', 'close', 'start_drag',
        'choose_profile_picture', 'add_local_plugin', 'start_resize',
        'media_video_load', 'media_video_control', 'media_video_status',
        'media_video_geometry', 'media_video_stop',
        'set_media_fullscreen', 'media_fullscreen_status',
    }

    def __init__(self, api: core.AppAPI, parent=None):
        super().__init__(parent)
        self.api = api
        self.pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix='klightten-api')

    @Slot(str, str, str)
    def call(self, request_id: str, method: str, args_json: str):
        if method in self.GUI_METHODS:
            self._execute(request_id, method, args_json)
        else:
            self.pool.submit(self._execute, request_id, method, args_json)

    def _execute(self, request_id: str, method: str, args_json: str):
        try:
            args = json.loads(args_json or '[]')
            if not isinstance(args, list):
                raise ValueError('API arguments must be a list.')
            target = getattr(self.api, method, None)
            if target is None or method.startswith('_'):
                raise AttributeError(f'Unknown API method: {method}')
            result = target(*args)
            payload = json.dumps({'ok_bridge': True, 'value': result}, ensure_ascii=False)
        except Exception as exc:
            payload = json.dumps({
                'ok_bridge': False,
                'error': str(exc),
                'trace': traceback.format_exc(limit=2),
            }, ensure_ascii=False)
        try:
            self.resultReady.emit(request_id, payload)
        except Exception:
            pass

    def shutdown(self):
        self.pool.shutdown(wait=False, cancel_futures=True)


class KlighttenWindow(QMainWindow):
    def __init__(self, app_url: str, api: core.AppAPI):
        super().__init__()
        self.api = api
        self.setWindowTitle(core.APP_NAME)
        self.setMinimumSize(680, 480)
        self.resize(1260, 820)
        self.setWindowFlags(self.windowFlags() | _qt_frameless_flag())

        self.view = QWebEngineView(self)
        self.view.setStyleSheet('background:#050611; border:0;')
        self.setStyleSheet('background:#050611;')
        self.setCentralWidget(self.view)

        # Native MPV target is a sibling of QWebEngineView under QMainWindow.
        # It is never a child of QWebEngineView. This is the layout that
        # successfully rendered ani-cli media before the 2.5 regression.
        self.video_surface = QWidget(self)
        self.video_surface.setStyleSheet('background:#000; border:0;')
        try:
            attr_enum = getattr(Qt, 'WidgetAttribute', Qt)
            self.video_surface.setAttribute(getattr(attr_enum, 'WA_NativeWindow'), True)
            dont_native_ancestors = getattr(attr_enum, 'WA_DontCreateNativeAncestors', None)
            if dont_native_ancestors is not None:
                self.video_surface.setAttribute(dont_native_ancestors, True)
        except Exception:
            pass
        self.video_surface.setGeometry(0, 0, 16, 16)
        self.video_surface.hide()

        self._video_mpv = shutil.which('mpv')
        self._video_process = None
        self._video_socket = ''
        self._video_log_path = ''
        self._video_log_handle = None
        self._video_url = ''
        self._video_last_error = ''
        self._video_volume = 70.0
        self._media_fullscreen = False
        self._media_restore_maximized = False
        self._media_restore_geometry = None

        # The native MPV overlay must never take keyboard focus. Keeping
        # WebEngine focused makes F/F11/Esc reliable while video is showing.
        try:
            focus_enum = getattr(Qt, 'FocusPolicy', Qt)
            self.video_surface.setFocusPolicy(getattr(focus_enum, 'NoFocus'))
        except Exception:
            pass

        self.tray = QSystemTrayIcon(self)
        icon_path = core.BASE_DIR / 'assets' / 'klightten-media.svg'
        try:
            self.tray.setIcon(QIcon(str(icon_path)))
        except Exception:
            pass
        self.tray.setToolTip('KLIGHTTEN MEDIA')
        tray_menu = QMenu()
        show_action = QAction('Show KLIGHTTEN MEDIA', self)
        show_action.triggered.connect(self.restore_from_tray)
        quit_action = QAction('Quit', self)
        quit_action.triggered.connect(self._quit_from_tray)
        tray_menu.addAction(show_action)
        tray_menu.addSeparator()
        tray_menu.addAction(quit_action)
        self.tray.setContextMenu(tray_menu)
        try:
            self.tray.activated.connect(self._tray_activated)
        except Exception:
            pass
        if QSystemTrayIcon.isSystemTrayAvailable():
            self.tray.show()

        profile = QWebEngineProfile('KLIGHTTEN_MEDIA', self)
        profile.setPersistentStoragePath(str(core.CONFIG_DIR / 'qt-webengine'))
        profile.setCachePath(str(core.CONFIG_DIR / 'qt-webengine-cache'))
        try:
            profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies)
        except Exception:
            try:
                profile.setPersistentCookiesPolicy(QWebEngineProfile.AllowPersistentCookies)
            except Exception:
                pass

        self.interceptor = YouTubeIdentityInterceptor(self)
        profile.setUrlRequestInterceptor(self.interceptor)
        api.runtime_media_referrer_setter = self.interceptor.add_media_referrer

        page = QWebEnginePage(profile, self.view)
        try:
            page.setBackgroundColor(QColor('#050611'))
        except Exception:
            pass
        self.view.setPage(page)
        settings = page.settings()
        for attr, enabled in (
            ('PlaybackRequiresUserGesture', False),
            ('FullScreenSupportEnabled', True),
            ('JavascriptCanOpenWindows', True),
            ('ForceDarkMode', True),
        ):
            try:
                settings.setAttribute(_web_attribute(attr), enabled)
            except Exception:
                pass

        self.bridge = APIBridge(api, self)
        self.channel = QWebChannel(page)
        self.channel.registerObject('backend', self.bridge)
        page.setWebChannel(self.channel)

        try:
            page.fullScreenRequested.connect(self._handle_fullscreen_request)
        except Exception:
            pass

        page.load(QUrl(app_url))

    def _video_ipc(self, command, timeout=0.8):
        if not self._video_socket or self._video_process is None or self._video_process.poll() is not None:
            return {'error': 'player unavailable'}
        payload = json.dumps({'command': command}).encode('utf-8') + b'\n'
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                sock.settimeout(timeout)
                sock.connect(self._video_socket)
                sock.sendall(payload)
                data = b''
                while b'\n' not in data:
                    chunk = sock.recv(65536)
                    if not chunk:
                        break
                    data += chunk
            if not data:
                return {'error': 'empty response'}
            return json.loads(data.split(b'\n', 1)[0].decode('utf-8', errors='replace'))
        except Exception as exc:
            return {'error': str(exc)}

    def _video_get(self, name, default=None):
        response = self._video_ipc(['get_property', name])
        if response.get('error') == 'success':
            return response.get('data', default)
        return default

    def _read_video_log_tail(self):
        try:
            if self._video_log_handle:
                self._video_log_handle.flush()
            if self._video_log_path and Path(self._video_log_path).exists():
                text = Path(self._video_log_path).read_text(encoding='utf-8', errors='replace')
                return text[-3500:].strip()
        except Exception:
            pass
        return ''

    def set_remote_video_geometry(self, x, y, width, height, visible=True):
        try:
            # The JS media poller can continue while the Qt window is
            # minimized. Python is authoritative and must never re-show video
            # unless the KLIGHTTEN window is actually visible.
            visible = bool(visible and self.isVisible() and not self.isMinimized())

            x, y = int(x), int(y)
            width, height = max(32, int(width)), max(32, int(height))
            vw, vh = max(1, self.view.width()), max(1, self.view.height())

            if x >= vw or y >= vh or x + width <= 0 or y + height <= 0:
                visible = False

            clipped_x = max(0, x)
            clipped_y = max(0, y)
            clipped_w = min(width - max(0, -x), max(1, vw - clipped_x))
            clipped_h = min(height - max(0, -y), max(1, vh - clipped_y))

            origin = self.view.mapTo(self, QPoint(0, 0))
            gx = origin.x() + clipped_x
            gy = origin.y() + clipped_y

            self.video_surface.setGeometry(
                gx, gy, max(1, clipped_w), max(1, clipped_h)
            )
            if visible and self._video_process is not None and self._video_process.poll() is None:
                self.video_surface.show()
                self.video_surface.raise_()
            else:
                self.video_surface.hide()

            return {
                'ok': True,
                'visible': bool(visible),
                'fullscreen': bool(self.isFullScreen()),
                'x': gx, 'y': gy,
                'width': clipped_w, 'height': clipped_h,
            }
        except Exception as exc:
            try:
                self.video_surface.hide()
            except Exception:
                pass
            return {'ok': False, 'error': str(exc)}

    def load_remote_video(self, url, referrer='', args=None, autoplay=True, volume=70):
        url = str(url or '').strip()
        is_remote = url.startswith('http://') or url.startswith('https://')
        if not is_remote:
            try:
                local_path = Path(url).expanduser().resolve()
            except Exception:
                local_path = Path('/__invalid__')
            if not local_path.exists() or not local_path.is_file():
                return {'ok': False, 'error': 'Media source was not found.'}
            url = str(local_path)
        if not self._video_mpv:
            return {'ok': False, 'error': 'MPV is not installed. Run ./setup.sh.'}

        self.stop_remote_video()
        try:
            # Map and realize the target before giving MPV its WId. A hidden
            # unmapped target can become a permanent black rectangle on some
            # X11 drivers even when the mpv process itself is healthy.
            if self.isVisible() and not self.isMinimized():
                self.video_surface.show()
                self.video_surface.raise_()
                QApplication.processEvents()
            wid = int(self.video_surface.winId())
            QApplication.processEvents()
        except Exception as exc:
            self.video_surface.hide()
            return {'ok': False, 'error': f'Could not create native video surface: {exc}'}

        socket_path = str(
            Path(tempfile.gettempdir())
            / f'klightten-video-{os.getpid()}-{int(time.time()*1000)}.sock'
        )
        log_path = str(
            Path(tempfile.gettempdir())
            / f'klightten-video-{os.getpid()}.log'
        )
        try:
            Path(socket_path).unlink(missing_ok=True)
            Path(log_path).unlink(missing_ok=True)
        except Exception:
            pass

        self._video_volume = max(0.0, min(200.0, float(volume or 70)))
        cmd = [
            self._video_mpv,
            f'--wid={wid}',
            f'--input-ipc-server={socket_path}',
            '--input-terminal=no',
            '--force-window=yes',
            '--keep-open=no',
            '--osc=no',
            '--volume-max=200',
            f'--volume={self._video_volume:g}',
            '--really-quiet',
        ]
        if not bool(autoplay):
            cmd.append('--pause')

        # Forward only safe playback/network flags captured from ani-cli.
        allowed_prefixes = (
            '--referrer=', '--http-referrer=', '--user-agent=',
            '--http-header-fields=', '--cookies=', '--cookies-file=',
            '--tls-verify=', '--demuxer-lavf-o=',
        )
        seen_referrer = False
        for item in list(args or []):
            item = str(item or '')
            if item.startswith(('http://', 'https://')):
                continue
            if item.startswith(allowed_prefixes):
                if item.startswith(('--referrer=', '--http-referrer=')):
                    seen_referrer = True
                cmd.append(item)

        referrer = str(referrer or '').strip()
        if is_remote and referrer and not seen_referrer:
            cmd.append(f'--referrer={referrer}')
        cmd.append(url)

        try:
            self._video_log_handle = open(log_path, 'wb')
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=self._video_log_handle,
                stderr=self._video_log_handle,
                start_new_session=True,
            )
            self._video_process = proc
            self._video_socket = socket_path
            self._video_log_path = log_path
            self._video_url = url
            self._video_last_error = ''

            deadline = time.time() + 2.5
            while time.time() < deadline:
                if proc.poll() is not None:
                    log = self._read_video_log_tail()
                    self._video_last_error = log or f'MPV exited with code {proc.returncode}.'
                    self.stop_remote_video(keep_error=True)
                    return {'ok': False, 'error': self._video_last_error}
                if Path(socket_path).exists():
                    if self.isVisible() and not self.isMinimized():
                        self.video_surface.show()
                        self.video_surface.raise_()
                    else:
                        self.video_surface.hide()
                    return {
                        'ok': True,
                        'backend': 'mpv-native',
                        'embedded': True,
                        'url': url,
                    }
                QApplication.processEvents()
                time.sleep(0.025)

            self._video_last_error = 'MPV video IPC did not start.'
            self.stop_remote_video(keep_error=True)
            return {'ok': False, 'error': self._video_last_error}
        except Exception as exc:
            self._video_last_error = str(exc)
            self.stop_remote_video(keep_error=True)
            return {'ok': False, 'error': f'Could not start native MPV video: {exc}'}

    def control_remote_video(self, action, value=0):
        action = str(action or '').lower()
        if self._video_process is None or self._video_process.poll() is not None:
            return {'ok': False, 'error': self._video_last_error or 'No native video is playing.'}

        if action == 'toggle':
            paused = bool(self._video_get('pause', False))
            response = self._video_ipc(['set_property', 'pause', not paused])
            return {'ok': response.get('error') == 'success', 'playing': paused}
        if action == 'play':
            response = self._video_ipc(['set_property', 'pause', False])
            return {'ok': response.get('error') == 'success', 'playing': True}
        if action == 'pause':
            response = self._video_ipc(['set_property', 'pause', True])
            return {'ok': response.get('error') == 'success', 'playing': False}
        if action == 'seek-relative':
            response = self._video_ipc(['seek', float(value or 0), 'relative', 'exact'])
            return {'ok': response.get('error') == 'success'}
        if action == 'seek':
            response = self._video_ipc(['seek', max(0.0, float(value or 0)), 'absolute', 'exact'])
            return {'ok': response.get('error') == 'success'}
        if action == 'volume':
            self._video_volume = max(0.0, min(200.0, float(value or 0)))
            response = self._video_ipc(['set_property', 'volume', self._video_volume])
            return {
                'ok': response.get('error') == 'success',
                'volume': round(self._video_volume),
            }
        return {'ok': False, 'error': 'Unknown native-video command.'}

    def remote_video_status(self):
        proc = self._video_process
        if proc is None:
            return {
                'ok': True, 'active': False, 'playing': False,
                'state': 'idle', 'position': 0.0, 'duration': 0.0,
                'error': self._video_last_error,
            }

        if proc.poll() is not None:
            log = self._read_video_log_tail()
            error = log or self._video_last_error or f'MPV exited with code {proc.returncode}.'
            self._video_last_error = error
            self.stop_remote_video(keep_error=True)
            return {
                'ok': False, 'active': False, 'playing': False,
                'state': 'error', 'position': 0.0, 'duration': 0.0,
                'error': error,
            }

        paused = bool(self._video_get('pause', False))
        position = float(self._video_get('time-pos', 0.0) or 0.0)
        duration = float(self._video_get('duration', 0.0) or 0.0)
        eof = bool(self._video_get('eof-reached', False))
        return {
            'ok': True,
            'active': True,
            'playing': not paused and not eof,
            'state': 'ended' if eof else ('paused' if paused else 'playing'),
            'position': round(position, 3),
            'duration': round(duration, 3),
            'volume': round(self._video_volume),
            'eos': eof,
            'backend': 'mpv-native',
            'url': self._video_url,
        }

    def stop_remote_video(self, keep_error=False):
        proc = self._video_process
        self._video_process = None
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=1.0)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

        try:
            if self._video_log_handle:
                self._video_log_handle.close()
        except Exception:
            pass
        self._video_log_handle = None

        try:
            if self._video_socket:
                Path(self._video_socket).unlink(missing_ok=True)
        except Exception:
            pass

        self._video_socket = ''
        self._video_url = ''
        try:
            self.video_surface.hide()
        except Exception:
            pass

        if not keep_error:
            self._video_last_error = ''
        return {'ok': True}

    def media_fullscreen_status(self):
        return {
            'ok': True,
            'fullscreen': bool(self._media_fullscreen),
            'qt_fullscreen': bool(self.isFullScreen()),
        }

    def set_media_fullscreen(self, enabled=False):
        enabled = bool(enabled)
        try:
            if enabled == self._media_fullscreen:
                return self.media_fullscreen_status()

            if enabled:
                self._media_restore_maximized = bool(self.isMaximized())
                try:
                    self._media_restore_geometry = self.saveGeometry()
                except Exception:
                    self._media_restore_geometry = None
                self._media_fullscreen = True
                self.video_surface.hide()
                self.showFullScreen()
            else:
                self._media_fullscreen = False
                self.video_surface.hide()
                self.showNormal()
                if self._media_restore_geometry is not None:
                    try:
                        self.restoreGeometry(self._media_restore_geometry)
                    except Exception:
                        pass
                if self._media_restore_maximized:
                    self.showMaximized()

            QApplication.processEvents()
            self.raise_()
            self.activateWindow()
            try:
                self.view.setFocus()
            except Exception:
                pass

            # Let CSS finish its fullscreen layout, then place the native MPV
            # target over the resized media stage.
            self.view.page().runJavaScript(
                'setTimeout(()=>window.syncNativeVideoGeometry && '
                'window.nativeMediaActive && window.syncNativeVideoGeometry(true),40);'
            )
            result = self.media_fullscreen_status()
            result['ok'] = True
            return result
        except Exception as exc:
            self._media_fullscreen = bool(self.isFullScreen())
            return {'ok': False, 'fullscreen': self._media_fullscreen, 'error': str(exc)}

    def hide_to_tray(self):
        try:
            self.video_surface.hide()
        except Exception:
            pass
        if not QSystemTrayIcon.isSystemTrayAvailable():
            self.showMinimized()
            return
        self.hide()
        try:
            icon_enum = getattr(getattr(QSystemTrayIcon, 'MessageIcon', QSystemTrayIcon), 'Information')
            self.tray.showMessage('KLIGHTTEN MEDIA', 'Running in the background. Use the tray icon to restore.', icon_enum, 1800)
        except Exception:
            pass

    def restore_from_tray(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()
        try:
            QApplication.processEvents()
            if self.isVisible() and not self.isMinimized() and self._video_process is not None and self._video_process.poll() is None:
                self.view.page().runJavaScript(
                    'window.nativeMediaActive && window.syncNativeVideoGeometry && window.syncNativeVideoGeometry(true);'
                )
        except Exception:
            pass

    def _tray_activated(self, reason):
        try:
            trigger = getattr(getattr(QSystemTrayIcon, 'ActivationReason', QSystemTrayIcon), 'Trigger')
            dbl = getattr(getattr(QSystemTrayIcon, 'ActivationReason', QSystemTrayIcon), 'DoubleClick')
            if reason in (trigger, dbl):
                self.restore_from_tray()
        except Exception:
            self.restore_from_tray()

    def _quit_from_tray(self):
        try:
            self.api.close()
        except Exception:
            QApplication.instance().quit()

    def _handle_fullscreen_request(self, request):
        try:
            request.accept()
            self.set_media_fullscreen(bool(request.toggleOn()))
            self.view.page().runJavaScript(
                f'window.setMediaFullscreenFromNative && '
                f'window.setMediaFullscreenFromNative({str(bool(request.toggleOn())).lower()});'
            )
        except Exception:
            pass


    def keyPressEvent(self, event):
        try:
            key_enum = getattr(Qt, 'Key', Qt)
            if self._media_fullscreen and event.key() == getattr(key_enum, 'Key_Escape'):
                self.set_media_fullscreen(False)
                self.view.page().runJavaScript(
                    'window.setMediaFullscreenFromNative && window.setMediaFullscreenFromNative(false);'
                )
                event.accept()
                return
        except Exception:
            pass
        return super().keyPressEvent(event)

    def moveEvent(self, event):
        try:
            if self.isVisible() and not self.isMinimized() and self._video_process is not None and self._video_process.poll() is None:
                self.view.page().runJavaScript(
                    'window.nativeMediaActive && window.syncNativeVideoGeometry && window.syncNativeVideoGeometry(true);'
                )
        except Exception:
            pass
        return super().moveEvent(event)

    def resizeEvent(self, event):
        try:
            if self._video_process is not None and self._video_process.poll() is None:
                self.view.page().runJavaScript(
                    'window.nativeMediaActive && window.syncNativeVideoGeometry && window.syncNativeVideoGeometry(true);'
                )
        except Exception:
            pass
        return super().resizeEvent(event)

    def changeEvent(self, event):
        try:
            if event.type() == _event_window_state_change():
                if self.isMinimized():
                    self.video_surface.hide()
                    self.view.page().runJavaScript(
                        'window.pauseYouTubeForWindowState && window.pauseYouTubeForWindowState();'
                    )
                elif self.isVisible():
                    QApplication.processEvents()
                    if self._video_process is not None and self._video_process.poll() is not None:
                        self.video_surface.hide()
                    elif self._video_process is not None:
                        self.view.page().runJavaScript(
                            'window.nativeMediaActive && window.syncNativeVideoGeometry && window.syncNativeVideoGeometry(true);'
                        )
        except Exception:
            pass
        return super().changeEvent(event)

    def closeEvent(self, event):
        try:
            self.stop_remote_video()
        except Exception:
            pass
        try:
            self.bridge.shutdown()
        except Exception:
            pass
        try:
            if self.api.audio is not None and hasattr(self.api.audio, 'shutdown'):
                self.api.audio.shutdown()
        except Exception:
            pass
        event.accept()
        try:
            QApplication.instance().quit()
        except Exception:
            pass


def main() -> int:
    if not core.UI_FILE.exists():
        print(f'UI file not found: {core.UI_FILE}')
        return 1

    # Prevent creation of native widget siblings inside Qt Quick/WebEngine.
    # This MUST be set before QApplication exists.
    try:
        app_attr_enum = getattr(Qt, 'ApplicationAttribute', Qt)
        dont_native_siblings = getattr(app_attr_enum, 'AA_DontCreateNativeWidgetSiblings', None)
        if dont_native_siblings is not None:
            QApplication.setAttribute(dont_native_siblings, True)
    except Exception:
        pass

    # Qt WebEngine/Chromium is the primary shell.
    app = QApplication(sys.argv)
    apply_dark_qt_palette(app)
    app.setQuitOnLastWindowClosed(False)
    app.setApplicationName(APP_ID)
    app.setOrganizationName('KLIGHTTEN')
    try:
        app.setDesktopFileName(APP_ID)
    except Exception:
        pass

    server, app_url = core.start_local_app_server()
    api = core.AppAPI()
    api.runtime_info = {
        'render_engine': f'{QT_API} Qt WebEngine (Chromium)',
        'youtube_app_id': APP_ID,
        'youtube_referer': YOUTUBE_REFERER,
        'explicit_youtube_referer': True,
        'dark_chromium_shell': True,
        'native_video_overlay': 'QMainWindow sibling + Qt Quick software',
        'dont_create_native_widget_siblings': True,
        'page_origin': app_url.rsplit('/ui/index.html', 1)[0],
    }

    window = KlighttenWindow(app_url, api)
    api.runtime_diagnostics_provider = lambda: {
        'youtube_intercepted_requests': int(window.interceptor.youtube_request_count),
        'last_youtube_request': window.interceptor.last_youtube_url,
    }
    adapter = QtWindowAdapter(window)
    api.bind_window(adapter)
    window.show()

    code = 0
    try:
        code = app.exec()
    finally:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
    return int(code)


if __name__ == '__main__':
    raise SystemExit(main())

#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

export QT_QUICK_BACKEND=software


# Automatic legacy cleanup for replaced KLIGHTTEN builds.
# Only app-specific generated/obsolete files are touched.
rm -rf "$APP_DIR/__pycache__" "$APP_DIR/ui/__pycache__" "$APP_DIR/.pytest_cache" 2>/dev/null || true
rm -f \
  "$APP_DIR/downloader.py" \
  "$APP_DIR/download_helper.py" \
  "$APP_DIR/youtube_downloader.py" \
  "$APP_DIR/pytube_plugin.py" 2>/dev/null || true
rm -rf "$APP_DIR/plugins/pytube" "$APP_DIR/plugins/downloader" 2>/dev/null || true

# Remove harmless platform/editor leftovers when users replace builds in-place.
find "$APP_DIR" -maxdepth 3 -type f \( -name '*.pyc' -o -name '.DS_Store' -o -name 'Thumbs.db' \) -delete 2>/dev/null || true

# Pytube belonged only to the removed downloader integration. Remove it from
# KLIGHTTEN's own virtualenv automatically; never touch the system Python.
if [[ -x "$APP_DIR/.venv/bin/python" ]]; then
  if "$APP_DIR/.venv/bin/python" -m pip show pytube >/dev/null 2>&1; then
    "$APP_DIR/.venv/bin/python" -m pip uninstall -y pytube >/dev/null 2>&1 || true
  fi
fi

if [[ ! -x ".venv/bin/python" ]]; then
  echo "KLIGHTTEN MUSIC is not set up yet."
  echo "Run: ./setup.sh"
  exit 1
fi

if .venv/bin/python - <<'PY' >/dev/null 2>&1
try:
    from PyQt6.QtWebEngineWidgets import QWebEngineView
except Exception:
    from PyQt5.QtWebEngineWidgets import QWebEngineView
PY
then
  exec .venv/bin/python qt_shell.py
else
  echo "Qt WebEngine is missing. KLIGHTTEN MUSIC 2.0 needs the Chromium-based playback shell."
  echo "Run: ./setup.sh"
  exit 1
fi

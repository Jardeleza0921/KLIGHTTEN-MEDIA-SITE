# KLIGHTTEN MEDIA 2.7 — Polished Controls

This build is a UI/interaction polish pass over the working 2.6.1 base.

## Control design

KLIGHTTEN now uses a consistent inline SVG icon set with no external icon
library or network dependency.

The control type now matches the job:

- **Transport** — compact icon-only controls.
- **Fullscreen / Shuffle / Repeat / Floating video** — icon + label toggle
  buttons with visible active state and `aria-pressed`.
- **Low-End Mode** — a real binary switch.
- **Sound presets** — segmented mode buttons.
- **Themes** — radio-style selection tiles with a selected check marker.
- **Destructive actions** — clearly styled danger buttons with trash/X icons.

## Keyboard controls

Outside text inputs and the ani-cli terminal:

- `Space` — Play / Pause
- `M` — Mute / Unmute
- `Left` — Seek back 10 seconds
- `Right` — Seek ahead 10 seconds
- `S` — Shuffle
- `R` — Repeat Off / All / One
- `F` or `F11` — Fullscreen toggle
- `Esc` — Exit fullscreen

A shortcut reference is included in Settings.

## Other polish

- Proper SVG icons for navigation and window controls.
- Fullscreen icon changes between expand and collapse.
- Volume button changes icon for mute / low / normal / boosted volume.
- Favorite button has a filled-heart state.
- Queue shuffle/repeat buttons show their current state.
- Floating video toggle exposes its active state.
- Theme and sound choices expose their selected state for accessibility.
- Keyboard focus rings and disabled-button styling are consistent.
- Reduced-motion preference is respected.
- App title/version metadata updated to 2.7.
- Automatic legacy cleanup from 2.6.1 is preserved and also removes harmless
  `.pyc`, `.DS_Store`, and `Thumbs.db` leftovers.

## Cleanup safety

Automatic cleanup never deletes:

- music or videos
- converted files
- user libraries
- favorites, queue or history
- OAuth/account credentials
- system applications/packages

## Upgrade

```bash
cd ~/Documents/KLIGHTTEN_MEDIA
chmod +x run.sh diagnose.sh
./run.sh
```

No setup rerun is required when updating from 2.6.1.
